<?php

//use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Route;
//use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});

///**
// * 1.中间件的使用:
// *  权限验证：
// *      登录时携带一个 role 字段，该字段代表用户的权限，登录后通过 session 保存；
// *      在首页中点击 「用户管理」 时，进行 role 中间件验证，判断用户是否有对应权限【可以使用 in_array 函数判断】；
// *      有权限进入管理页面，没有权限重定向到登录页面；
// *
// *
// * 2.事件的使用: 邮件的发送 - 日志记录
// *  日志记录:
// *      注册时使用 create 新增一个用户，调用 id 属性；
// *      通过判断 id 来判断是否注册成功，成功则发送一封邮件；
// *      邮件的发送通过事件分发来实现，创建 事件 与 监听器并绑定；在监听器中通过 Log::info 来写入信息模拟邮件发送；
// *
// *  模型事件：
// *      创建观察者，注册观察者，在 created 方法中写入日志；
// *
// *
// * 3.队列的使用: 邮件发送, 通过队列保存; 当一次有很多邮件需要发送，服务器处理不过来，添加到队列中慢慢来；
// *  邮件发送：
// *      在 监听器 中实现 ShouldQueue 接口；其他不变，事件的内容就会放入队列而不会直接执行【观察者可以直接在观察者中继承上述接口】；
// *
// *
// * 4.模型关联：用户  商品
// *
// */
//
//
//Route::get('/', function () {
//    return view('index.index');
//    \Illuminate\Support\Facades\Storage::disk();
//});
//
//Route::get('login', function () {
//    return view('index.login');
//});
//
//Route::get('register', function () {
//    return view('index.register');
//});
//
//Route::namespace('Admin')->group(function(){
//    Route::post('login', 'LoginController@login');
//    Route::get('logout', 'LoginController@logout');
//
//    Route::post('register', 'RegisterController@register');
//
//    Route::get('index', 'AdminController@index');
////    Route::match(['get', 'post'], 'index', 'AdminController@index');
//
//    Route::get('edit/{id}', 'AdminController@edit')->name('edit');
//    Route::post('update', 'AdminController@update');
//
//    Route::get('create', 'AdminController@create');
//    Route::post('store', 'AdminController@store');
//
//    Route::get('show/{id}', 'AdminController@show')->name('show');
//});
//
//
////Route::resource('hello', 'Admin\AdminController');
//
//
//
//
////Route::get('queue', function () {
////    \App\Jobs\TestJob::dispatch('hello');
////});
//
//Route::get('weather/{city}', function ($city) {
//    dump(app('weather')->getWeather($city));
//});






Route::get('hello', function () {
    echo 123465;
});

