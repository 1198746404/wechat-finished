
  </div>

  <hr>

  <footer>
<p>&nbsp;&nbsp; Powered by <a href="http://bbs.emlsoft.com/" target="_blank">emlSoft</a>  2013-2019 Some rights reserved</p>
  </footer>

</div>


<script src="static/js/jquery.js"></script>
<script src="static/js/bootstrap.min.js"></script>
<script src="static/js/bootstrap-datepicker.js"></script>
<script src="static/js/bootstrap-datepicker.js"></script>


  <script>
$(function(){
	window.prettyPrint && prettyPrint();
	$('#datepicker').datepicker({
		format: 'yyyy-mm-dd'
	});
	$('#datepicker2').datepicker({
		format: 'yyyy-mm-dd'
	});
});
</script>
</body>
</html>