@include('public.head')

<div class="span10">

    <div class="page-header">
        <h3>添加个人信息</h3>
    </div>

    <div class="row-fluid">
        <div class="span12">

            <form class="form-horizontal" method="post" action="{{ url('store') }}">
                @csrf
                <div class="control-group">
                    <label for="input01" class="control-label">姓&nbsp;&nbsp;&nbsp;&nbsp;名：</label>
                    <div class="controls">
                        <input type="text" id="name" class="input-xlarge" name="name" value="qaz">
                    </div>
                </div>
                <div class="control-group">
                    <label for="input01" class="control-label">邮&nbsp;&nbsp;&nbsp;&nbsp;箱：</label>
                    <div class="controls">
                        <input type="text" id="name" class="input-xlarge" name="email" value="qaz@qq.com">
                    </div>
                </div>
                <div class="control-group">
                    <label for="input01" class="control-label">密&nbsp;&nbsp;&nbsp;&nbsp;码：</label>
                    <div class="controls">
                        <input type="text" id="name" class="input-xlarge" name="password" value="0000">
                    </div>
                </div>

                <div class="form-actions">
                    <button class="btn btn-success" type="submit">保存</button>
                    <a class="btn" href=""><i class="icon-share"></i> 返回</a>
                </div>
            </form>
        </div>
    </div>
</div>
@include('public.foot')
