@include('public.head')

<div class="span11">
    <div class="page-header">
        <h3></h3>
    </div>

    <div class="row-fluid">
        <div class="span12">
            <div class="add">
                {{ $user['name'] }}详情
            </div>
            <table width="100%" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th width="32">序号</th>
                    <th width="42">姓名</th>
                    <th width="47">年龄</th>
                    <th width="90" class="hidden-phone">性别</th>
                    <th width="33">创建时间</th>
                    <th width="33">修改时间</th>
                </tr>
                </thead>

                    <tbody>
                    <tr>
                        <td>{{ $user['id'] }}</td>
                        <td>{{ $user['name'] }}</td>
                        <td>{{ $user['age'] }}</td>
                        <td>{{ $user['sex'] }}</td>
                        <td>{{ $user['created_at'] }}</td>
                        <td>{{ $user['updated_at'] }}</td>
                    </tr>
                    </tbody>

            </table>


        </div>
    </div>
</div>

@include('public.foot')
