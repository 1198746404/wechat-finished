@include('public.head')

<div class="span11">
    <div class="page-header">
        <h3></h3>
    </div>

    <div class="row-fluid">
        <div class="span12">
            <div class="add">
                <a href="{{ url('create') }}">增加管理员</a>
            </div>
            <table width="100%" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th width="32">序号</th>
                    <th width="42">姓名</th>
                    <th width="47">邮箱</th>
                    <th width="90" class="hidden-phone">创建时间</th>
                    <th width="33">操作</th>
                </tr>
                </thead>

                @foreach($users as $user)
                    <tbody>
                    <tr>
                        <td>{{ $user->id }}</td>
                        <td>{{ $user->name }}</td>
                        <td>{{ $user->email }}</td>
                        <td>{{ $user->created_at }}</td>
                        <td>
                            <a class="btn btn-small" href="{{ route('edit', ['id' => $user->id]) }}"><i class="icon-edit"></i> 编辑</a>
                            <a class="btn btn-smaell" href=""><i class="icon-trash"></i> 删除</a>
                            <a class="btn btn-smaell" href="{{ route('show', ['id' => $user->id]) }}"><i class="icon-user"></i> 详情</a>
                        </td>
                    </tr>
                    </tbody>
                @endforeach

            </table>

            {{ $users->links() }}

        </div>
    </div>
</div>

@include('public.foot')
