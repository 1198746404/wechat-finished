@include('public.head')

<div class="span10">
		 
<h4>欢迎使用企业通讯录系统</h4>
<b>简介</b>
<p>企业通讯录管理系统,向企业员工随时随地的提供企业通讯录信息，用户可在手机端实时查看人员联系方式，拨打电话等全面提高了企业内部沟通效率。</p>
<hr />
<b>主要功能</b>
<p>主要功能有:用户管理(添加用户，删除用户用户，更新用户资料)；通讯录管理(添加通讯录，更新通讯录，删除),个人中心,配置管理等。</p>

<p>EML企业客户关系管理系统,是基于Linux开放性内核和Apache基础上Php+Mysql的智能B/S交互式服务系统。</p>

<p>EML系统移动端由移动端采用javascript、html5、ajax、json等技术。</p>
<p>中间件层包括函数库,由java开发,android操作系统、中间件、用户界面和应用软件组成。</p>
<p>最佳分辨率: 1440x900 最佳浏览器: 火狐Firefox</p>
<hr />
<b>官网动态</b>
 <div class="panel-body">
<iframe src="http://bbs.emlsoft.com/home/latest" height="100%" frameborder="0" scrolling="no">请升级您的浏览器以便正常访问emlsoft。</iframe>
</div>
<hr />
<b>登录状态</b>
<p>账号状态：正常</p>

</div>

@include('public.foot')
