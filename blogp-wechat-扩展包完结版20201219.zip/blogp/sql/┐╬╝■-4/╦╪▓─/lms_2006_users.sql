/*
 Navicat Premium Data Transfer

 Source Server         : mysql_上课_主
 Source Server Type    : MySQL
 Source Server Version : 80019
 Source Host           : 192.168.199.131:3306
 Source Schema         : lms_2006_users

 Target Server Type    : MySQL
 Target Server Version : 80019
 File Encoding         : 65001

 Date: 25/07/2020 21:27:21
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for lms_user_info
-- ----------------------------
DROP TABLE IF EXISTS `lms_user_info`;
CREATE TABLE `lms_user_info`  (
  `id` int(0) NOT NULL,
  `user_id` char(36) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `age` int(0) NULL DEFAULT NULL,
  `image` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `birthday` datetime(0) NULL DEFAULT NULL,
  `email` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sex` tinyint(1) NULL DEFAULT NULL,
  `identity_type` tinyint(1) NULL DEFAULT NULL,
  `identity_no` char(18) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `user_description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `level_id` int(0) NULL DEFAULT NULL,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  `deleted_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lms_users
-- ----------------------------
DROP TABLE IF EXISTS `lms_users`;
CREATE TABLE `lms_users`  (
  `id` char(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户id',
  `Openid` char(28) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'openid',
  `username` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户名称',
  `password` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '密码',
  `role_id` int(0) NULL DEFAULT NULL COMMENT '用户角色id',
  `vender_type` tinyint(1) NULL DEFAULT NULL COMMENT '第三方类型:1.QQ,2:微信',
  `status` tinyint(1) NULL DEFAULT NULL COMMENT '用户状态：1. 黑名单',
  `mobile` char(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号码',
  `login_ip` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '登录ip',
  `remember_token` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'token验证',
  `created_at` datetime(0) NULL DEFAULT NULL COMMENT '注册时间',
  `updated_at` datetime(0) NULL DEFAULT NULL COMMENT '最后一次修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_users
-- ----------------------------
INSERT INTO `lms_users` VALUES ('d8ea9331-2057-9f7d-bb3e-32b95e37debd', 'oqCL0s8DkK6CZy_cZFEx0TvfUM_Y', '星空', '$2y$10$nJc44kf7EVfXrnr40EwiDOJNWXYvd98MxEmuGjDKdAmZC8FLTRx/O', 1, 1, 1, NULL, '127.0.0.1', 'jt96HLtSGvyUuH0cJM1GSrBbjGqJHUHQtiMkQGl9cr2lm2aYWEdQj9NrFNsC', '2020-07-24 13:50:31', '2020-07-24 13:50:31');

SET FOREIGN_KEY_CHECKS = 1;
