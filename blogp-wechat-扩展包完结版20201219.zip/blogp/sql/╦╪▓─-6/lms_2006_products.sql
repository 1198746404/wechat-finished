/*
 Navicat Premium Data Transfer

 Source Server         : mysql_上课_主
 Source Server Type    : MySQL
 Source Server Version : 80019
 Source Host           : 192.168.199.131:3306
 Source Schema         : lms_2006_products

 Target Server Type    : MySQL
 Target Server Version : 80019
 File Encoding         : 65001

 Date: 01/08/2020 22:30:15
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for lms_categories
-- ----------------------------
DROP TABLE IF EXISTS `lms_categories`;
CREATE TABLE `lms_categories`  (
  `id` bigint(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(0) UNSIGNED NULL DEFAULT NULL,
  `is_directory` tinyint(1) NOT NULL,
  `level` int(0) UNSIGNED NOT NULL,
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 28 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_categories
-- ----------------------------
INSERT INTO `lms_categories` VALUES (1, '手机配件', NULL, 1, 0, '-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (2, '手机壳', 1, 0, 1, '-1-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (3, '贴膜', 1, 0, 1, '-1-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (4, '存储卡', 1, 0, 1, '-1-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (5, '数据线', 1, 0, 1, '-1-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (6, '充电器', 1, 0, 1, '-1-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (7, '耳机', 1, 1, 1, '-1-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (8, '有线耳机', 7, 0, 2, '-1-7-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (9, '蓝牙耳机', 7, 0, 2, '-1-7-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (10, '电脑配件', NULL, 1, 0, '-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (11, '显示器', 10, 0, 1, '-10-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (12, '显卡', 10, 0, 1, '-10-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (13, '内存', 10, 0, 1, '-10-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (14, 'CPU', 10, 0, 1, '-10-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (15, '主板', 10, 0, 1, '-10-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (16, '硬盘', 10, 0, 1, '-10-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (17, '电脑整机', NULL, 1, 0, '-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (18, '笔记本', 17, 0, 1, '-17-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (19, '台式机', 17, 0, 1, '-17-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (20, '平板电脑', 17, 0, 1, '-17-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (21, '一体机', 17, 0, 1, '-17-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (22, '服务器', 17, 0, 1, '-17-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (23, '工作站', 17, 0, 1, '-17-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (24, '手机通讯', NULL, 1, 0, '-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (25, '智能机', 24, 0, 1, '-24-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (26, '老人机', 24, 0, 1, '-24-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');
INSERT INTO `lms_categories` VALUES (27, '对讲机', 24, 0, 1, '-24-', '2020-07-28 06:45:04', '2020-07-28 06:45:04');

-- ----------------------------
-- Table structure for lms_product_descriptions
-- ----------------------------
DROP TABLE IF EXISTS `lms_product_descriptions`;
CREATE TABLE `lms_product_descriptions`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` int(0) UNSIGNED NULL DEFAULT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `lms_product_descriptions_ibfk_1`(`product_id`) USING BTREE,
  CONSTRAINT `lms_product_descriptions_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `lms_products` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 31 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_product_descriptions
-- ----------------------------
INSERT INTO `lms_product_descriptions` VALUES (1, 31, 'Ipsa nostrum est tenetur et.');
INSERT INTO `lms_product_descriptions` VALUES (2, 32, 'Veritatis cupiditate ut voluptatem aliquid.');
INSERT INTO `lms_product_descriptions` VALUES (3, 33, 'Ducimus tenetur minus tempora iure aut quis.');
INSERT INTO `lms_product_descriptions` VALUES (4, 34, 'Occaecati sint voluptates omnis aspernatur.');
INSERT INTO `lms_product_descriptions` VALUES (5, 35, 'Laboriosam et aut quod est nesciunt rerum.');
INSERT INTO `lms_product_descriptions` VALUES (6, 36, 'Provident facere tempora nihil ex saepe ut officiis.');
INSERT INTO `lms_product_descriptions` VALUES (7, 37, 'Pariatur eos optio architecto animi.');
INSERT INTO `lms_product_descriptions` VALUES (8, 38, 'Nisi doloribus dolor eum.');
INSERT INTO `lms_product_descriptions` VALUES (9, 39, 'Consequatur sed aut autem repellat.');
INSERT INTO `lms_product_descriptions` VALUES (10, 40, 'Dolor alias magnam numquam unde.');
INSERT INTO `lms_product_descriptions` VALUES (11, 41, 'Quia neque repellendus maxime natus repudiandae aspernatur libero amet.');
INSERT INTO `lms_product_descriptions` VALUES (12, 42, 'Fugit atque atque quod ut et enim animi doloremque.');
INSERT INTO `lms_product_descriptions` VALUES (13, 43, 'Praesentium aut ipsam minima beatae accusantium.');
INSERT INTO `lms_product_descriptions` VALUES (14, 44, 'Quaerat ut velit earum excepturi fuga et voluptatem quasi.');
INSERT INTO `lms_product_descriptions` VALUES (15, 45, 'Tenetur quo et debitis qui rem.');
INSERT INTO `lms_product_descriptions` VALUES (16, 46, 'Id necessitatibus doloribus officiis architecto est.');
INSERT INTO `lms_product_descriptions` VALUES (17, 47, 'Nostrum et dicta nemo in sit.');
INSERT INTO `lms_product_descriptions` VALUES (18, 48, 'Expedita magni modi natus cumque non ducimus voluptatum.');
INSERT INTO `lms_product_descriptions` VALUES (19, 49, 'Voluptatem molestiae ratione et quaerat inventore minima.');
INSERT INTO `lms_product_descriptions` VALUES (20, 50, 'Et neque iure consequatur est.');
INSERT INTO `lms_product_descriptions` VALUES (21, 51, 'Est cumque sint quia unde.');
INSERT INTO `lms_product_descriptions` VALUES (22, 52, 'Doloribus officia aut culpa fugit.');
INSERT INTO `lms_product_descriptions` VALUES (23, 53, 'Delectus occaecati non voluptatem quae harum quisquam.');
INSERT INTO `lms_product_descriptions` VALUES (24, 54, 'Quam rerum exercitationem suscipit aperiam id.');
INSERT INTO `lms_product_descriptions` VALUES (25, 55, 'Exercitationem earum corporis impedit totam qui a.');
INSERT INTO `lms_product_descriptions` VALUES (26, 56, 'Voluptate porro autem repellat sapiente nam.');
INSERT INTO `lms_product_descriptions` VALUES (27, 57, 'Explicabo similique magni nihil illo blanditiis quas.');
INSERT INTO `lms_product_descriptions` VALUES (28, 58, 'Quibusdam tempora nemo porro et modi quia sunt.');
INSERT INTO `lms_product_descriptions` VALUES (29, 59, 'Officia ut dolor corporis et officia.');
INSERT INTO `lms_product_descriptions` VALUES (30, 60, 'Sint fugit ea debitis et error sit eveniet.');
INSERT INTO `lms_product_descriptions` VALUES (31, 61, NULL);
INSERT INTO `lms_product_descriptions` VALUES (32, 63, NULL);
INSERT INTO `lms_product_descriptions` VALUES (33, 64, NULL);
INSERT INTO `lms_product_descriptions` VALUES (34, 65, NULL);
INSERT INTO `lms_product_descriptions` VALUES (35, 66, NULL);
INSERT INTO `lms_product_descriptions` VALUES (36, 67, NULL);
INSERT INTO `lms_product_descriptions` VALUES (37, 68, NULL);
INSERT INTO `lms_product_descriptions` VALUES (38, 69, NULL);
INSERT INTO `lms_product_descriptions` VALUES (39, 70, '1111111111111111111111111111111111111');
INSERT INTO `lms_product_descriptions` VALUES (40, 71, '<p></p><p>1111111111111111111</p>');
INSERT INTO `lms_product_descriptions` VALUES (41, 72, '<p></p><p>111111111111111111</p>');
INSERT INTO `lms_product_descriptions` VALUES (42, 73, '<p></p><p>华为电脑</p>');
INSERT INTO `lms_product_descriptions` VALUES (43, 74, '<p></p><p>11111111111</p>');

-- ----------------------------
-- Table structure for lms_product_images
-- ----------------------------
DROP TABLE IF EXISTS `lms_product_images`;
CREATE TABLE `lms_product_images`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` int(0) NULL DEFAULT NULL,
  `image_url` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pic_desc` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `is_master` tinyint(0) NULL DEFAULT NULL,
  `pic_order` int(0) NULL DEFAULT NULL,
  `pic_status` tinyint(1) NULL DEFAULT NULL,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lms_product_sku_descriptions
-- ----------------------------
DROP TABLE IF EXISTS `lms_product_sku_descriptions`;
CREATE TABLE `lms_product_sku_descriptions`  (
  `id` int(0) NOT NULL,
  `product_sku_id` int(0) UNSIGNED NULL DEFAULT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `lms_product_sku_descriptions_ibfk_1`(`product_sku_id`) USING BTREE,
  CONSTRAINT `lms_product_sku_descriptions_ibfk_1` FOREIGN KEY (`product_sku_id`) REFERENCES `lms_product_skus` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lms_product_skus
-- ----------------------------
DROP TABLE IF EXISTS `lms_product_skus`;
CREATE TABLE `lms_product_skus`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `price` decimal(10, 2) NULL DEFAULT NULL,
  `stock` int(0) NULL DEFAULT NULL,
  `product_id` int(0) UNSIGNED NULL DEFAULT NULL,
  `status` tinyint(1) NULL DEFAULT 1,
  `parameter` json NULL,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  `deleted_at` datetime(0) NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `lms_product_skus_ibfk_1`(`product_id`) USING BTREE,
  CONSTRAINT `lms_product_skus_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `lms_products` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 94 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_product_skus
-- ----------------------------
INSERT INTO `lms_product_skus` VALUES (1, 'perspiciatis', 7428.00, 74904, 1, 1, NULL, '2020-07-30 12:24:38', '2020-07-30 12:24:38', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (2, 'autem', 4500.00, 4903, 1, 1, NULL, '2020-07-30 12:24:38', '2020-07-30 12:24:38', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (3, 'iure', 4343.00, 57232, 1, 1, NULL, '2020-07-30 12:24:38', '2020-07-30 12:24:38', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (4, 'asperiores', 227.00, 77908, 31, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (5, 'iste', 171.00, 36157, 31, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (6, 'quia', 8162.00, 70886, 31, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (7, 'perferendis', 2918.00, 68370, 32, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (8, 'fugit', 3708.00, 98683, 32, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (9, 'enim', 38.00, 41576, 32, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (10, 'maiores', 7268.00, 71632, 33, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (11, 'natus', 5170.00, 8583, 33, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (12, 'nam', 824.00, 39541, 33, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (13, 'voluptatibus', 473.00, 76740, 34, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (14, 'magnam', 7593.00, 35043, 34, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (15, 'excepturi', 2201.00, 92530, 34, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (16, 'unde', 6654.00, 75560, 35, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (17, 'tempore', 7505.00, 9342, 35, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (18, 'soluta', 1449.00, 68813, 35, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (19, 'nemo', 7903.00, 49489, 36, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (20, 'officiis', 1245.00, 82770, 36, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (21, 'voluptatibus', 408.00, 79840, 36, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (22, 'labore', 1987.00, 87196, 37, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (23, 'est', 3101.00, 12474, 37, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (24, 'facilis', 2519.00, 64258, 37, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (25, 'quis', 5678.00, 35933, 38, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (26, 'odio', 5046.00, 57772, 38, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (27, 'sed', 5992.00, 66096, 38, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (28, 'et', 8443.00, 80069, 39, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (29, 'libero', 4634.00, 80825, 39, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (30, 'id', 1043.00, 49557, 39, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (31, 'reiciendis', 5623.00, 59255, 40, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (32, 'iusto', 2627.00, 95616, 40, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (33, 'harum', 8422.00, 43574, 40, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (34, 'temporibus', 2490.00, 24468, 41, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (35, 'sit', 9423.00, 5880, 41, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (36, 'quis', 4479.00, 49528, 41, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (37, 'facilis', 538.00, 28721, 42, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (38, 'ea', 9357.00, 58056, 42, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (39, 'excepturi', 4334.00, 91086, 42, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (40, 'quia', 8737.00, 26427, 43, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (41, 'aliquid', 3904.00, 29501, 43, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (42, 'voluptatem', 5482.00, 53786, 43, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (43, 'aperiam', 6961.00, 36054, 44, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (44, 'non', 6734.00, 54481, 44, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (45, 'modi', 2070.00, 23056, 44, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (46, 'iste', 8391.00, 61080, 45, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (47, 'autem', 6795.00, 3228, 45, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (48, 'similique', 914.00, 85872, 45, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (49, 'soluta', 7801.00, 35602, 46, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (50, 'sint', 8825.00, 63601, 46, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (51, 'quo', 8913.00, 60497, 46, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (52, 'consequatur', 7582.00, 85820, 47, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (53, 'enim', 4501.00, 77511, 47, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (54, 'hic', 1619.00, 25952, 47, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (55, 'eum', 9584.00, 21376, 48, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (56, 'aut', 6143.00, 20743, 48, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (57, 'accusamus', 4819.00, 31588, 48, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (58, 'sed', 1414.00, 90520, 49, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (59, 'deleniti', 6700.00, 88874, 49, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (60, 'sunt', 7003.00, 38473, 49, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (61, 'aliquam', 9157.00, 97098, 50, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (62, 'animi', 5388.00, 32777, 50, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (63, 'in', 6968.00, 17729, 50, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (64, 'laborum', 8037.00, 12986, 51, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (65, 'placeat', 2845.00, 83772, 51, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (66, 'iusto', 2670.00, 77598, 51, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (67, 'nihil', 6215.00, 81933, 52, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (68, 'amet', 2591.00, 79904, 52, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (69, 'eos', 5104.00, 91339, 52, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (70, 'quos', 5559.00, 83232, 53, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (71, 'cum', 6379.00, 77251, 53, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (72, 'libero', 8376.00, 1019, 53, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (73, 'consequatur', 6126.00, 4792, 54, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (74, 'dolores', 791.00, 10645, 54, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (75, 'beatae', 3893.00, 97724, 54, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (76, 'dolore', 8801.00, 69339, 55, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (77, 'vel', 7078.00, 3906, 55, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (78, 'et', 3537.00, 47361, 55, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (79, 'sint', 3367.00, 75282, 56, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (80, 'doloribus', 8380.00, 92638, 56, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (81, 'repellendus', 6485.00, 98423, 56, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (82, 'quia', 5875.00, 92410, 57, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (83, 'et', 1037.00, 35841, 57, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (84, 'repudiandae', 2687.00, 64051, 57, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (85, 'velit', 1305.00, 31437, 58, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (86, 'ut', 8620.00, 46622, 58, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (87, 'itaque', 1952.00, 75649, 58, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (88, 'veritatis', 8657.00, 11405, 59, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (89, 'recusandae', 4751.00, 94811, 59, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (90, 'qui', 3757.00, 30363, 59, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (91, 'dolores', 1223.00, 9047, 60, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (92, 'quisquam', 6923.00, 59182, 60, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (93, 'nisi', 4270.00, 45052, 60, 1, NULL, '2020-07-30 12:26:12', '2020-07-30 12:26:12', NULL, NULL);
INSERT INTO `lms_product_skus` VALUES (94, '黑色joker 1米70', 1.00, 111, 69, 1, NULL, '2020-08-01 06:19:08', '2020-08-01 06:19:08', NULL, '111111');
INSERT INTO `lms_product_skus` VALUES (95, '黑色joker 1米70', 1.00, 11111, 71, 1, NULL, '2020-08-01 07:48:19', '2020-08-01 07:48:19', NULL, '111111');
INSERT INTO `lms_product_skus` VALUES (96, '华为运行内存16G  物理内存1T', 10.00, 111, 73, 1, NULL, '2020-08-01 14:16:01', '2020-08-01 14:18:00', NULL, '16G');
INSERT INTO `lms_product_skus` VALUES (97, '华为运行内存16G  物理内存520MB', 12222.00, 1111, 73, 1, NULL, '2020-08-01 14:16:49', '2020-08-01 14:18:00', NULL, '2222');

-- ----------------------------
-- Table structure for lms_products
-- ----------------------------
DROP TABLE IF EXISTS `lms_products`;
CREATE TABLE `lms_products`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_core` char(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `title` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `bar_code` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `category_id` int(0) NULL DEFAULT NULL,
  `status` tinyint(1) NULL DEFAULT NULL,
  `audit_status` tinyint(0) NULL DEFAULT 0,
  `shop_id` int(0) NULL DEFAULT NULL,
  `description_id` int(0) NULL DEFAULT NULL,
  `rating` double(8, 2) NULL DEFAULT NULL,
  `sold_count` int(0) NULL DEFAULT NULL,
  `review_count` int(0) NULL DEFAULT NULL,
  `price` decimal(10, 2) NULL DEFAULT NULL,
  `image` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 61 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_products
-- ----------------------------
INSERT INTO `lms_products` VALUES (1, '', 'labore', '', 3, 1, 1, 3, NULL, 0.00, 0, 0, 4343.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/1B3n0ATKrn.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (2, '', 'laboriosam', '', 5, 1, 1, 3, NULL, 2.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/82Wf2sg8gM.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (3, '', 'et', '', 16, 1, 1, 3, NULL, 0.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/1B3n0ATKrn.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (4, '', 'quaerat', '', 27, 1, 1, 3, NULL, 1.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/nIvBAQO5Pj.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (5, '', 'officia', '', 19, 1, 1, 4, NULL, 4.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/2JMRaFwRpo.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (6, '', 'et', '', 25, 1, 1, 1, NULL, 4.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/C0bVuKB2nt.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (7, '', 'ea', '', 15, 1, 1, 2, NULL, 1.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/C0bVuKB2nt.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (8, '', 'hic', '', 23, 1, 1, 1, NULL, 2.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/7kG1HekGK6.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (9, '', 'dolores', '', 25, 1, 1, 3, NULL, 2.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/2JMRaFwRpo.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (10, '', 'sed', '', 2, 1, 1, 3, NULL, 3.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/uYEHCJ1oRp.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (11, '', 'est', '', 11, 1, 1, 1, NULL, 5.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/82Wf2sg8gM.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (12, '', 'voluptatem', '', 8, 1, 1, 3, NULL, 0.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/XrtIwzrxj7.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (13, '', 'nemo', '', 4, 1, 1, 1, NULL, 2.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/82Wf2sg8gM.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (14, '', 'minus', '', 27, 1, 1, 2, NULL, 4.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/pa7DrV43Mw.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (15, '', 'odit', '', 3, 1, 1, 3, NULL, 1.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/82Wf2sg8gM.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (16, '', 'quos', '', 5, 1, 1, 3, NULL, 0.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/r3BNRe4zXG.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (17, '', 'velit', '', 19, 1, 1, 1, NULL, 4.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/XrtIwzrxj7.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (18, '', 'commodi', '', 5, 1, 1, 3, NULL, 0.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/pa7DrV43Mw.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (19, '', 'non', '', 8, 1, 1, 1, NULL, 5.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/pa7DrV43Mw.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (20, '', 'nostrum', '', 22, 1, 1, 2, NULL, 2.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/7kG1HekGK6.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (21, '', 'maxime', '', 2, 1, 1, 3, NULL, 5.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/nIvBAQO5Pj.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (22, '', 'ea', '', 9, 1, 1, 1, NULL, 4.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/7kG1HekGK6.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (23, '', 'eligendi', '', 9, 1, 1, 2, NULL, 2.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/uYEHCJ1oRp.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (24, '', 'quia', '', 27, 1, 1, 3, NULL, 3.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/1B3n0ATKrn.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (25, '', 'dicta', '', 19, 1, 1, 3, NULL, 2.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/uYEHCJ1oRp.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (26, '', 'iure', '', 13, 1, 1, 3, NULL, 2.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/nIvBAQO5Pj.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (27, '', 'dignissimos', '', 3, 1, 1, 3, NULL, 5.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/nIvBAQO5Pj.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (28, '', 'sed', '', 5, 1, 1, 1, NULL, 4.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/r3BNRe4zXG.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (29, '', 'earum', '', 6, 1, 1, 2, NULL, 0.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/7kG1HekGK6.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (30, '', 'et', '', 27, 1, 1, 3, NULL, 4.00, 0, 0, 0.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/pa7DrV43Mw.jpg', '2020-07-30 12:24:38', '2020-07-30 12:24:38');
INSERT INTO `lms_products` VALUES (31, '', 'est', '', 14, 1, 1, 2, NULL, 0.00, 0, 0, 171.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/uYEHCJ1oRp.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (32, '', 'repellat', '', 6, 1, 1, 2, NULL, 2.00, 0, 0, 38.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/1B3n0ATKrn.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (33, '', 'vel', '', 20, 1, 1, 3, NULL, 2.00, 0, 0, 824.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/82Wf2sg8gM.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (34, '', 'suscipit', '', 25, 1, 1, 2, NULL, 2.00, 0, 0, 473.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/XrtIwzrxj7.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (35, '', 'sint', '', 13, 1, 1, 2, NULL, 5.00, 0, 0, 1449.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/1B3n0ATKrn.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (36, '', 'aut', '', 2, 1, 1, 2, NULL, 0.00, 0, 0, 408.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/XrtIwzrxj7.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (37, '', 'nihil', '', 26, 1, 1, 2, NULL, 5.00, 0, 0, 1987.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/uYEHCJ1oRp.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (38, '', 'quidem', '', 27, 1, 1, 3, NULL, 5.00, 0, 0, 5046.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/82Wf2sg8gM.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (39, '', 'ipsum', '', 13, 1, 1, 3, NULL, 0.00, 0, 0, 1043.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/2JMRaFwRpo.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (40, '', 'molestiae', '', 12, 1, 1, 3, NULL, 4.00, 0, 0, 2627.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/nIvBAQO5Pj.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (41, '', 'ducimus', '', 4, 1, 1, 3, NULL, 0.00, 0, 0, 2490.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/r3BNRe4zXG.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (42, '', 'quia', '', 23, 1, 1, 3, NULL, 4.00, 0, 0, 538.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/pa7DrV43Mw.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (43, '', 'ullam', '', 14, 1, 1, 1, NULL, 3.00, 0, 0, 3904.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/nIvBAQO5Pj.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (44, '', 'quia', '', 26, 1, 1, 2, NULL, 1.00, 0, 0, 2070.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/nIvBAQO5Pj.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (45, '', 'rerum', '', 4, 1, 1, 3, NULL, 1.00, 0, 0, 914.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/pa7DrV43Mw.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (46, '', 'ratione', '', 20, 1, 1, 1, NULL, 3.00, 0, 0, 7801.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/nIvBAQO5Pj.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (47, '', 'quos', '', 27, 1, 1, 2, NULL, 3.00, 0, 0, 1619.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/1B3n0ATKrn.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (48, '', 'accusantium', '', 27, 1, 1, 3, NULL, 1.00, 0, 0, 4819.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/XrtIwzrxj7.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (49, '', 'possimus', '', 25, 1, 1, 3, NULL, 0.00, 0, 0, 1414.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/pa7DrV43Mw.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (50, '', 'distinctio', '', 4, 1, 1, 3, NULL, 0.00, 0, 0, 5388.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/82Wf2sg8gM.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (51, '', 'itaque', '', 23, 1, 1, 2, NULL, 5.00, 0, 0, 2670.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/pa7DrV43Mw.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (52, '', 'qui', '', 3, 1, 1, 3, NULL, 4.00, 0, 0, 2591.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/C0bVuKB2nt.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (53, '', 'ut', '', 12, 1, 1, 1, NULL, 4.00, 0, 0, 5559.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/2JMRaFwRpo.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (54, '', 'saepe', '', 26, 1, 1, 1, NULL, 1.00, 0, 0, 791.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/pa7DrV43Mw.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (55, '', 'voluptatum', '', 14, 1, 1, 2, NULL, 1.00, 0, 0, 3537.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/nIvBAQO5Pj.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (56, '', 'est', '', 25, 1, 1, 2, NULL, 4.00, 0, 0, 3367.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/82Wf2sg8gM.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (57, '', 'modi', '', 23, 1, 1, 1, NULL, 5.00, 0, 0, 1037.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/C0bVuKB2nt.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (58, '', 'dolorum', '', 19, 1, 1, 2, NULL, 1.00, 0, 0, 1305.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/1B3n0ATKrn.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (59, '', 'dolorem', '', 27, 1, 1, 2, NULL, 3.00, 0, 0, 3757.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/uYEHCJ1oRp.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (60, '', 'distinctio', '', 25, 1, 1, 1, NULL, 1.00, 0, 0, 1223.00, 'https://cdn.learnku.com/uploads/images/201806/01/5320/C0bVuKB2nt.jpg', '2020-07-30 12:26:12', '2020-07-30 12:26:12');
INSERT INTO `lms_products` VALUES (61, NULL, '奇偶陈可人', '11111', 7, 1, 0, 2, NULL, NULL, NULL, NULL, 0.00, 'images/)6BBF)6[BO_X3_`DAJ9EE9U.png', '2020-07-31 08:57:38', '2020-07-31 08:57:38');
INSERT INTO `lms_products` VALUES (62, '1596260344', 'joker', '11111', 7, 1, 0, 2, NULL, NULL, NULL, NULL, 1.00, 'images/BKZD)CHD94@H4{RK@QPRGRI.png', '2020-08-01 05:39:04', '2020-08-01 05:39:04');
INSERT INTO `lms_products` VALUES (63, '1596260501', 'joker', '11111', 1, 1, 0, 2, NULL, NULL, NULL, NULL, 1.00, 'images/949f0d0c29eead6751b1ba978ab6b4cd.png', '2020-08-01 05:41:41', '2020-08-01 05:41:41');
INSERT INTO `lms_products` VALUES (64, '1596261010', 'joker', '11111', 1, 1, 0, 2, NULL, NULL, NULL, NULL, 1.00, 'images/e6050409e53cf95252094629d29e1db3.png', '2020-08-01 05:50:10', '2020-08-01 05:50:10');
INSERT INTO `lms_products` VALUES (65, NULL, 'joker', '11111', 1, 1, 0, 2, NULL, NULL, NULL, NULL, 1.00, 'images/1df1f9579f25cdf07c329d4a4aad85a6.png', '2020-08-01 05:51:58', '2020-08-01 05:51:58');
INSERT INTO `lms_products` VALUES (66, NULL, 'jocker', '11111', 1, 1, 0, 2, NULL, NULL, NULL, NULL, 1.00, 'images/c54a79a1c5f041e34dfa48bb49ac3c63.png', '2020-08-01 05:53:34', '2020-08-01 05:53:34');
INSERT INTO `lms_products` VALUES (67, NULL, 'jocker', '11111', 1, 1, 0, 2, NULL, NULL, NULL, NULL, 0.00, 'images/84992394ca21fc17e9ef973343964137.png', '2020-08-01 05:54:00', '2020-08-01 05:54:00');
INSERT INTO `lms_products` VALUES (68, '1596262387', '车前草', '11111', 1, 1, 0, 2, NULL, NULL, NULL, NULL, 1.00, 'images/PHP零基础.png', '2020-08-01 06:13:07', '2020-08-01 06:13:07');
INSERT INTO `lms_products` VALUES (69, '1596262748', '完成全额', '11111', 1, 1, 0, 2, NULL, NULL, NULL, NULL, 1.00, 'images/2fcb1ea2bdf8429e310e3d551ea44688.png', '2020-08-01 06:19:08', '2020-08-01 06:19:08');
INSERT INTO `lms_products` VALUES (70, '1596267351', 'wdwcwdc', '11111', 1, 1, 0, 2, NULL, NULL, NULL, NULL, 0.00, 'images/2cbb10e4a8b9b3bf501fbc24737d1fb5.png', '2020-08-01 07:35:51', '2020-08-01 07:35:51');
INSERT INTO `lms_products` VALUES (71, '1596268098', 'joker', '11111', 1, 1, 0, 2, NULL, NULL, NULL, NULL, 1.00, 'images/c79594c258566ea5be5b45619f7875a2.png', '2020-08-01 07:48:18', '2020-08-01 07:48:18');
INSERT INTO `lms_products` VALUES (72, '1596290915', '华为手机', '1111111111111111', 24, 1, 0, 2, NULL, NULL, NULL, NULL, 0.00, 'images/627b6be6933f064281459efc2b7fbb30.png', '2020-08-01 14:08:35', '2020-08-01 14:08:35');
INSERT INTO `lms_products` VALUES (73, '1596291480', '华为电脑', '22222222222', 1, 1, 0, 2, NULL, NULL, NULL, NULL, 10.00, 'images/Tomcat专题.png', '2020-08-01 14:16:01', '2020-08-01 14:18:00');
INSERT INTO `lms_products` VALUES (74, '1596291542', 'will', '111111111111', 24, 1, 0, 5, NULL, NULL, NULL, NULL, 0.00, 'images/14b12e103c88b3e35af764c1523aeee7.png', '2020-08-01 14:19:02', '2020-08-01 14:19:02');

-- ----------------------------
-- Table structure for lms_shops
-- ----------------------------
DROP TABLE IF EXISTS `lms_shops`;
CREATE TABLE `lms_shops`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `admin_user_id` int(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  `deleted_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_shops
-- ----------------------------
INSERT INTO `lms_shops` VALUES (1, '星空', '2020-07-30 08:11:42', NULL, '2020-07-30 08:11:42', NULL);
INSERT INTO `lms_shops` VALUES (2, 'harry', '2020-07-30 08:15:08', 1, '2020-07-30 08:15:08', NULL);
INSERT INTO `lms_shops` VALUES (3, '星空', '2020-07-30 08:56:16', 2, '2020-07-30 08:56:16', NULL);
INSERT INTO `lms_shops` VALUES (4, 'will', '2020-07-30 12:55:41', 2, '2020-07-30 12:55:41', NULL);
INSERT INTO `lms_shops` VALUES (5, 'leo', '2020-08-01 14:18:24', 1, '2020-08-01 14:18:24', NULL);

SET FOREIGN_KEY_CHECKS = 1;
