/*
 Navicat Premium Data Transfer

 Source Server         : mysql_上课_主
 Source Server Type    : MySQL
 Source Server Version : 80019
 Source Host           : 192.168.199.131:3306
 Source Schema         : lms_2006_users

 Target Server Type    : MySQL
 Target Server Version : 80019
 File Encoding         : 65001

 Date: 01/08/2020 22:30:22
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for lms_admin_menu
-- ----------------------------
DROP TABLE IF EXISTS `lms_admin_menu`;
CREATE TABLE `lms_admin_menu`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `parent_id` int(0) NOT NULL DEFAULT 0,
  `order` int(0) NOT NULL DEFAULT 0,
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `uri` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_admin_menu
-- ----------------------------
INSERT INTO `lms_admin_menu` VALUES (1, 0, 1, 'Dashboard', 'fa-bar-chart', '/', NULL, NULL, NULL);
INSERT INTO `lms_admin_menu` VALUES (2, 0, 6, 'Admin', 'fa-tasks', NULL, NULL, NULL, '2020-07-30 09:00:05');
INSERT INTO `lms_admin_menu` VALUES (3, 2, 7, 'Users', 'fa-users', 'auth/users', NULL, NULL, '2020-07-30 07:55:31');
INSERT INTO `lms_admin_menu` VALUES (4, 2, 8, 'Roles', 'fa-user', 'auth/roles', NULL, NULL, '2020-07-30 07:55:31');
INSERT INTO `lms_admin_menu` VALUES (5, 2, 9, 'Permission', 'fa-ban', 'auth/permissions', NULL, NULL, '2020-07-30 07:55:31');
INSERT INTO `lms_admin_menu` VALUES (6, 2, 10, 'Menu', 'fa-bars', 'auth/menu', NULL, NULL, '2020-07-30 07:55:31');
INSERT INTO `lms_admin_menu` VALUES (7, 2, 11, 'Operation log', 'fa-history', 'auth/logs', NULL, NULL, '2020-07-30 07:55:31');
INSERT INTO `lms_admin_menu` VALUES (8, 0, 4, '用户管理', 'fa-users', '/users', NULL, '2020-07-27 07:37:32', '2020-07-30 07:55:31');
INSERT INTO `lms_admin_menu` VALUES (10, 0, 5, '分类管理', 'fa-bars', '/categories', NULL, '2020-07-28 09:23:00', '2020-07-30 07:55:31');
INSERT INTO `lms_admin_menu` VALUES (11, 0, 3, '商品管理', 'fa-cubes', '/products', NULL, '2020-07-30 05:25:14', '2020-07-30 07:55:31');
INSERT INTO `lms_admin_menu` VALUES (12, 0, 2, '店铺管理', 'fa-home', '/shops', NULL, '2020-07-30 07:54:49', '2020-07-30 07:55:31');

-- ----------------------------
-- Table structure for lms_admin_operation_log
-- ----------------------------
DROP TABLE IF EXISTS `lms_admin_operation_log`;
CREATE TABLE `lms_admin_operation_log`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(0) NOT NULL,
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `input` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `lms_admin_operation_log_user_id_index`(`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 548 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_admin_operation_log
-- ----------------------------
INSERT INTO `lms_admin_operation_log` VALUES (1, 1, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-27 07:26:37', '2020-07-27 07:26:37');
INSERT INTO `lms_admin_operation_log` VALUES (2, 1, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-27 07:32:03', '2020-07-27 07:32:03');
INSERT INTO `lms_admin_operation_log` VALUES (3, 1, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-27 07:32:49', '2020-07-27 07:32:49');
INSERT INTO `lms_admin_operation_log` VALUES (4, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-27 07:32:55', '2020-07-27 07:32:55');
INSERT INTO `lms_admin_operation_log` VALUES (5, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-27 07:33:00', '2020-07-27 07:33:00');
INSERT INTO `lms_admin_operation_log` VALUES (6, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-27 07:34:37', '2020-07-27 07:34:37');
INSERT INTO `lms_admin_operation_log` VALUES (7, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-27 07:34:39', '2020-07-27 07:34:39');
INSERT INTO `lms_admin_operation_log` VALUES (8, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-27 07:34:42', '2020-07-27 07:34:42');
INSERT INTO `lms_admin_operation_log` VALUES (9, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-27 07:34:43', '2020-07-27 07:34:43');
INSERT INTO `lms_admin_operation_log` VALUES (10, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-27 07:34:46', '2020-07-27 07:34:46');
INSERT INTO `lms_admin_operation_log` VALUES (11, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-27 07:34:47', '2020-07-27 07:34:47');
INSERT INTO `lms_admin_operation_log` VALUES (12, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"fa-users\",\"uri\":\"\\/users\",\"roles\":[null],\"permission\":null,\"_token\":\"66mKpviIcNmgSSlDK9E2DXPyyOXQtUfF3zY64mTr\"}', '2020-07-27 07:37:32', '2020-07-27 07:37:32');
INSERT INTO `lms_admin_operation_log` VALUES (13, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-27 07:37:32', '2020-07-27 07:37:32');
INSERT INTO `lms_admin_operation_log` VALUES (14, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"_token\":\"66mKpviIcNmgSSlDK9E2DXPyyOXQtUfF3zY64mTr\",\"_order\":\"[{\\\"id\\\":1},{\\\"id\\\":8},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]}]\"}', '2020-07-27 07:37:42', '2020-07-27 07:37:42');
INSERT INTO `lms_admin_operation_log` VALUES (15, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-27 07:37:43', '2020-07-27 07:37:43');
INSERT INTO `lms_admin_operation_log` VALUES (16, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-27 07:37:49', '2020-07-27 07:37:49');
INSERT INTO `lms_admin_operation_log` VALUES (17, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"fa-users\",\"uri\":\"\\/users\",\"roles\":[null],\"permission\":null,\"_token\":\"66mKpviIcNmgSSlDK9E2DXPyyOXQtUfF3zY64mTr\"}', '2020-07-27 07:38:24', '2020-07-27 07:38:24');
INSERT INTO `lms_admin_operation_log` VALUES (18, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-27 07:38:24', '2020-07-27 07:38:24');
INSERT INTO `lms_admin_operation_log` VALUES (19, 1, 'admin/auth/menu/9', 'DELETE', '127.0.0.1', '{\"_method\":\"delete\",\"_token\":\"66mKpviIcNmgSSlDK9E2DXPyyOXQtUfF3zY64mTr\"}', '2020-07-27 07:38:32', '2020-07-27 07:38:32');
INSERT INTO `lms_admin_operation_log` VALUES (20, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-27 07:38:32', '2020-07-27 07:38:32');
INSERT INTO `lms_admin_operation_log` VALUES (21, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-27 08:01:35', '2020-07-27 08:01:35');
INSERT INTO `lms_admin_operation_log` VALUES (22, 1, 'admin/users', 'GET', '127.0.0.1', '[]', '2020-07-27 08:02:02', '2020-07-27 08:02:02');
INSERT INTO `lms_admin_operation_log` VALUES (23, 1, 'admin/users', 'GET', '127.0.0.1', '[]', '2020-07-27 08:11:30', '2020-07-27 08:11:30');
INSERT INTO `lms_admin_operation_log` VALUES (24, 1, 'admin/users', 'GET', '127.0.0.1', '[]', '2020-07-27 08:12:35', '2020-07-27 08:12:35');
INSERT INTO `lms_admin_operation_log` VALUES (25, 1, 'admin/users', 'GET', '127.0.0.1', '[]', '2020-07-27 08:12:50', '2020-07-27 08:12:50');
INSERT INTO `lms_admin_operation_log` VALUES (26, 1, 'admin/users', 'GET', '127.0.0.1', '[]', '2020-07-27 08:13:18', '2020-07-27 08:13:18');
INSERT INTO `lms_admin_operation_log` VALUES (27, 1, 'admin/users', 'GET', '127.0.0.1', '[]', '2020-07-27 09:14:55', '2020-07-27 09:14:55');
INSERT INTO `lms_admin_operation_log` VALUES (28, 1, 'admin/users', 'GET', '127.0.0.1', '[]', '2020-07-27 09:26:56', '2020-07-27 09:26:56');
INSERT INTO `lms_admin_operation_log` VALUES (29, 1, 'admin/users', 'GET', '127.0.0.1', '[]', '2020-07-27 09:27:31', '2020-07-27 09:27:31');
INSERT INTO `lms_admin_operation_log` VALUES (30, 1, 'admin/users', 'GET', '127.0.0.1', '[]', '2020-07-27 11:59:14', '2020-07-27 11:59:14');
INSERT INTO `lms_admin_operation_log` VALUES (31, 1, 'admin/users/0', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-27 11:59:17', '2020-07-27 11:59:17');
INSERT INTO `lms_admin_operation_log` VALUES (32, 1, 'admin/users', 'GET', '127.0.0.1', '[]', '2020-07-27 11:59:18', '2020-07-27 11:59:18');
INSERT INTO `lms_admin_operation_log` VALUES (33, 1, 'admin/users', 'GET', '127.0.0.1', '[]', '2020-07-27 12:12:20', '2020-07-27 12:12:20');
INSERT INTO `lms_admin_operation_log` VALUES (34, 1, 'admin/users', 'GET', '127.0.0.1', '[]', '2020-07-27 12:25:48', '2020-07-27 12:25:48');
INSERT INTO `lms_admin_operation_log` VALUES (35, 1, 'admin/users/0', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-27 12:25:52', '2020-07-27 12:25:52');
INSERT INTO `lms_admin_operation_log` VALUES (36, 1, 'admin/users', 'GET', '127.0.0.1', '[]', '2020-07-27 12:25:52', '2020-07-27 12:25:52');
INSERT INTO `lms_admin_operation_log` VALUES (37, 1, 'admin/users', 'GET', '127.0.0.1', '[]', '2020-07-27 12:28:42', '2020-07-27 12:28:42');
INSERT INTO `lms_admin_operation_log` VALUES (38, 1, 'admin/users/d8ea9331-2057-9f7d-bb3e-32b95e37debd', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-27 12:28:53', '2020-07-27 12:28:53');
INSERT INTO `lms_admin_operation_log` VALUES (39, 1, 'admin/users/d8ea9331-2057-9f7d-bb3e-32b95e37debd', 'GET', '127.0.0.1', '[]', '2020-07-27 12:29:10', '2020-07-27 12:29:10');
INSERT INTO `lms_admin_operation_log` VALUES (40, 1, 'admin/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-27 12:29:30', '2020-07-27 12:29:30');
INSERT INTO `lms_admin_operation_log` VALUES (41, 1, 'admin/auth/users', 'GET', '127.0.0.1', '[]', '2020-07-28 09:22:23', '2020-07-28 09:22:23');
INSERT INTO `lms_admin_operation_log` VALUES (42, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-28 09:22:28', '2020-07-28 09:22:28');
INSERT INTO `lms_admin_operation_log` VALUES (43, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"\\u5206\\u7c7b\\u7ba1\\u7406\",\"icon\":\"fa-bars\",\"uri\":\"\\/categories\",\"roles\":[null],\"permission\":null,\"_token\":\"0Pyw8hy2QCbvKVOrFlLD1lJv76TnsBV3mfV12EiA\"}', '2020-07-28 09:23:00', '2020-07-28 09:23:00');
INSERT INTO `lms_admin_operation_log` VALUES (44, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-28 09:23:00', '2020-07-28 09:23:00');
INSERT INTO `lms_admin_operation_log` VALUES (45, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"_token\":\"0Pyw8hy2QCbvKVOrFlLD1lJv76TnsBV3mfV12EiA\",\"_order\":\"[{\\\"id\\\":1},{\\\"id\\\":8},{\\\"id\\\":10},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]}]\"}', '2020-07-28 09:23:06', '2020-07-28 09:23:06');
INSERT INTO `lms_admin_operation_log` VALUES (46, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-28 09:23:06', '2020-07-28 09:23:06');
INSERT INTO `lms_admin_operation_log` VALUES (47, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-28 09:23:09', '2020-07-28 09:23:09');
INSERT INTO `lms_admin_operation_log` VALUES (48, 1, 'admin/categories', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-28 09:23:13', '2020-07-28 09:23:13');
INSERT INTO `lms_admin_operation_log` VALUES (49, 1, 'admin/categories/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-28 09:23:32', '2020-07-28 09:23:32');
INSERT INTO `lms_admin_operation_log` VALUES (50, 1, 'admin/categories', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-28 09:29:00', '2020-07-28 09:29:00');
INSERT INTO `lms_admin_operation_log` VALUES (51, 1, 'admin/categories/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-28 09:29:02', '2020-07-28 09:29:02');
INSERT INTO `lms_admin_operation_log` VALUES (52, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-28 09:29:06', '2020-07-28 09:29:06');
INSERT INTO `lms_admin_operation_log` VALUES (53, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-28 09:29:06', '2020-07-28 09:29:06');
INSERT INTO `lms_admin_operation_log` VALUES (54, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\"}', '2020-07-28 09:29:07', '2020-07-28 09:29:07');
INSERT INTO `lms_admin_operation_log` VALUES (55, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\"}', '2020-07-28 09:29:08', '2020-07-28 09:29:08');
INSERT INTO `lms_admin_operation_log` VALUES (56, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-28 09:29:08', '2020-07-28 09:29:08');
INSERT INTO `lms_admin_operation_log` VALUES (57, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u8033\\u673a\"}', '2020-07-28 09:29:09', '2020-07-28 09:29:09');
INSERT INTO `lms_admin_operation_log` VALUES (58, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u8033\"}', '2020-07-28 09:29:09', '2020-07-28 09:29:09');
INSERT INTO `lms_admin_operation_log` VALUES (59, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-28 09:29:17', '2020-07-28 09:29:17');
INSERT INTO `lms_admin_operation_log` VALUES (60, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-28 09:29:19', '2020-07-28 09:29:19');
INSERT INTO `lms_admin_operation_log` VALUES (61, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-28 09:29:19', '2020-07-28 09:29:19');
INSERT INTO `lms_admin_operation_log` VALUES (62, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-29 13:06:56', '2020-07-29 13:06:56');
INSERT INTO `lms_admin_operation_log` VALUES (63, 1, 'admin/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-29 13:07:05', '2020-07-29 13:07:05');
INSERT INTO `lms_admin_operation_log` VALUES (64, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-29 13:07:09', '2020-07-29 13:07:09');
INSERT INTO `lms_admin_operation_log` VALUES (65, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-29 13:07:10', '2020-07-29 13:07:10');
INSERT INTO `lms_admin_operation_log` VALUES (66, 1, 'admin/auth/users/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-29 13:07:15', '2020-07-29 13:07:15');
INSERT INTO `lms_admin_operation_log` VALUES (67, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-30 05:24:50', '2020-07-30 05:24:50');
INSERT INTO `lms_admin_operation_log` VALUES (68, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"\\u5546\\u54c1\\u7ba1\\u7406\",\"icon\":\"fa-cubes\",\"uri\":\"\\/products\",\"roles\":[null],\"permission\":null,\"_token\":\"8vMpHcn55Ircxj07uWVLJbJ7deTtLYiqBquNQ3RK\"}', '2020-07-30 05:25:13', '2020-07-30 05:25:13');
INSERT INTO `lms_admin_operation_log` VALUES (69, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-30 05:25:14', '2020-07-30 05:25:14');
INSERT INTO `lms_admin_operation_log` VALUES (70, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"_token\":\"8vMpHcn55Ircxj07uWVLJbJ7deTtLYiqBquNQ3RK\",\"_order\":\"[{\\\"id\\\":1},{\\\"id\\\":11},{\\\"id\\\":8},{\\\"id\\\":10},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]}]\"}', '2020-07-30 05:25:22', '2020-07-30 05:25:22');
INSERT INTO `lms_admin_operation_log` VALUES (71, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:25:22', '2020-07-30 05:25:22');
INSERT INTO `lms_admin_operation_log` VALUES (72, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-30 05:25:24', '2020-07-30 05:25:24');
INSERT INTO `lms_admin_operation_log` VALUES (73, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:25:27', '2020-07-30 05:25:27');
INSERT INTO `lms_admin_operation_log` VALUES (74, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:31:58', '2020-07-30 05:31:58');
INSERT INTO `lms_admin_operation_log` VALUES (75, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:32:06', '2020-07-30 05:32:06');
INSERT INTO `lms_admin_operation_log` VALUES (76, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:32:10', '2020-07-30 05:32:10');
INSERT INTO `lms_admin_operation_log` VALUES (77, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:32:11', '2020-07-30 05:32:11');
INSERT INTO `lms_admin_operation_log` VALUES (78, 1, 'admin/auth/permissions/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:32:27', '2020-07-30 05:32:27');
INSERT INTO `lms_admin_operation_log` VALUES (79, 1, 'admin/categories', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:32:59', '2020-07-30 05:32:59');
INSERT INTO `lms_admin_operation_log` VALUES (80, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:33:06', '2020-07-30 05:33:06');
INSERT INTO `lms_admin_operation_log` VALUES (81, 1, 'admin/auth/setting', 'GET', '127.0.0.1', '[]', '2020-07-30 05:34:42', '2020-07-30 05:34:42');
INSERT INTO `lms_admin_operation_log` VALUES (82, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '[]', '2020-07-30 05:34:45', '2020-07-30 05:34:45');
INSERT INTO `lms_admin_operation_log` VALUES (83, 1, 'admin/categories', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:35:14', '2020-07-30 05:35:14');
INSERT INTO `lms_admin_operation_log` VALUES (84, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:36:17', '2020-07-30 05:36:17');
INSERT INTO `lms_admin_operation_log` VALUES (85, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:37:32', '2020-07-30 05:37:32');
INSERT INTO `lms_admin_operation_log` VALUES (86, 1, 'admin/auth/permissions/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:37:34', '2020-07-30 05:37:34');
INSERT INTO `lms_admin_operation_log` VALUES (87, 1, 'admin/auth/permissions', 'POST', '127.0.0.1', '{\"slug\":\"shops\",\"name\":\"\\u5546\\u5bb6\",\"http_method\":[null],\"http_path\":\"\\/admin\\/\\r\\n\\/admin\\/auth\\/login\\r\\n\\/admin\\/auth\\/logout\\r\\n\\/admin\\/auth\\/setting\\r\\n\\/admin\\/products\\/*\",\"_token\":\"8vMpHcn55Ircxj07uWVLJbJ7deTtLYiqBquNQ3RK\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/auth\\/permissions\"}', '2020-07-30 05:37:59', '2020-07-30 05:37:59');
INSERT INTO `lms_admin_operation_log` VALUES (88, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '[]', '2020-07-30 05:38:00', '2020-07-30 05:38:00');
INSERT INTO `lms_admin_operation_log` VALUES (89, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:38:10', '2020-07-30 05:38:10');
INSERT INTO `lms_admin_operation_log` VALUES (90, 1, 'admin/auth/roles/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:38:13', '2020-07-30 05:38:13');
INSERT INTO `lms_admin_operation_log` VALUES (91, 1, 'admin/auth/roles', 'POST', '127.0.0.1', '{\"slug\":\"shops\",\"name\":\"\\u5546\\u5bb6\",\"permissions\":[\"6\",null],\"_token\":\"8vMpHcn55Ircxj07uWVLJbJ7deTtLYiqBquNQ3RK\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/auth\\/roles\"}', '2020-07-30 05:38:23', '2020-07-30 05:38:23');
INSERT INTO `lms_admin_operation_log` VALUES (92, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '[]', '2020-07-30 05:38:23', '2020-07-30 05:38:23');
INSERT INTO `lms_admin_operation_log` VALUES (93, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:38:31', '2020-07-30 05:38:31');
INSERT INTO `lms_admin_operation_log` VALUES (94, 1, 'admin/auth/users/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:38:33', '2020-07-30 05:38:33');
INSERT INTO `lms_admin_operation_log` VALUES (95, 1, 'admin/auth/users', 'POST', '127.0.0.1', '{\"username\":\"starsky\",\"name\":\"starsky\",\"password\":\"starsky99\",\"password_confirmation\":\"starsky99\",\"roles\":[\"2\",null],\"permissions\":[\"6\",null],\"_token\":\"8vMpHcn55Ircxj07uWVLJbJ7deTtLYiqBquNQ3RK\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/auth\\/users\"}', '2020-07-30 05:39:24', '2020-07-30 05:39:24');
INSERT INTO `lms_admin_operation_log` VALUES (96, 1, 'admin/auth/users', 'GET', '127.0.0.1', '[]', '2020-07-30 05:39:24', '2020-07-30 05:39:24');
INSERT INTO `lms_admin_operation_log` VALUES (97, 1, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:39:32', '2020-07-30 05:39:32');
INSERT INTO `lms_admin_operation_log` VALUES (98, 2, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-30 05:39:40', '2020-07-30 05:39:40');
INSERT INTO `lms_admin_operation_log` VALUES (99, 2, 'admin/categories', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:39:44', '2020-07-30 05:39:44');
INSERT INTO `lms_admin_operation_log` VALUES (100, 2, 'admin/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:39:45', '2020-07-30 05:39:45');
INSERT INTO `lms_admin_operation_log` VALUES (101, 2, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:39:46', '2020-07-30 05:39:46');
INSERT INTO `lms_admin_operation_log` VALUES (102, 2, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:39:48', '2020-07-30 05:39:48');
INSERT INTO `lms_admin_operation_log` VALUES (103, 2, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:39:50', '2020-07-30 05:39:50');
INSERT INTO `lms_admin_operation_log` VALUES (104, 2, 'admin/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:39:55', '2020-07-30 05:39:55');
INSERT INTO `lms_admin_operation_log` VALUES (105, 2, 'admin/categories', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:39:57', '2020-07-30 05:39:57');
INSERT INTO `lms_admin_operation_log` VALUES (106, 2, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:39:59', '2020-07-30 05:39:59');
INSERT INTO `lms_admin_operation_log` VALUES (107, 2, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:40:05', '2020-07-30 05:40:05');
INSERT INTO `lms_admin_operation_log` VALUES (108, 1, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-30 05:40:12', '2020-07-30 05:40:12');
INSERT INTO `lms_admin_operation_log` VALUES (109, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:40:18', '2020-07-30 05:40:18');
INSERT INTO `lms_admin_operation_log` VALUES (110, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:40:22', '2020-07-30 05:40:22');
INSERT INTO `lms_admin_operation_log` VALUES (111, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:40:23', '2020-07-30 05:40:23');
INSERT INTO `lms_admin_operation_log` VALUES (112, 1, 'admin/auth/permissions/6/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:40:30', '2020-07-30 05:40:30');
INSERT INTO `lms_admin_operation_log` VALUES (113, 1, 'admin/auth/permissions/6', 'PUT', '127.0.0.1', '{\"slug\":\"shops\",\"name\":\"\\u5546\\u5bb6\",\"http_method\":[null],\"http_path\":\"\\/\\r\\n\\/auth\\/login\\r\\n\\/auth\\/logout\\r\\n\\/auth\\/setting\\r\\n\\/products\\/*\",\"_token\":\"7WS6WG99m07j1AnkJd6QrMyzJHPUULovNa4yEAMQ\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/auth\\/permissions\"}', '2020-07-30 05:40:44', '2020-07-30 05:40:44');
INSERT INTO `lms_admin_operation_log` VALUES (114, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '[]', '2020-07-30 05:40:44', '2020-07-30 05:40:44');
INSERT INTO `lms_admin_operation_log` VALUES (115, 1, 'admin/auth/permissions/5', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:40:50', '2020-07-30 05:40:50');
INSERT INTO `lms_admin_operation_log` VALUES (116, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:40:59', '2020-07-30 05:40:59');
INSERT INTO `lms_admin_operation_log` VALUES (117, 1, 'admin/auth/permissions/6', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:41:04', '2020-07-30 05:41:04');
INSERT INTO `lms_admin_operation_log` VALUES (118, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:41:10', '2020-07-30 05:41:10');
INSERT INTO `lms_admin_operation_log` VALUES (119, 1, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:41:16', '2020-07-30 05:41:16');
INSERT INTO `lms_admin_operation_log` VALUES (120, 2, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-30 05:41:30', '2020-07-30 05:41:30');
INSERT INTO `lms_admin_operation_log` VALUES (121, 2, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:41:33', '2020-07-30 05:41:33');
INSERT INTO `lms_admin_operation_log` VALUES (122, 2, 'admin/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:41:38', '2020-07-30 05:41:38');
INSERT INTO `lms_admin_operation_log` VALUES (123, 2, 'admin/categories', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:41:39', '2020-07-30 05:41:39');
INSERT INTO `lms_admin_operation_log` VALUES (124, 2, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:41:41', '2020-07-30 05:41:41');
INSERT INTO `lms_admin_operation_log` VALUES (125, 2, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:41:41', '2020-07-30 05:41:41');
INSERT INTO `lms_admin_operation_log` VALUES (126, 2, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:41:46', '2020-07-30 05:41:46');
INSERT INTO `lms_admin_operation_log` VALUES (127, 1, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-30 05:41:52', '2020-07-30 05:41:52');
INSERT INTO `lms_admin_operation_log` VALUES (128, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:41:56', '2020-07-30 05:41:56');
INSERT INTO `lms_admin_operation_log` VALUES (129, 1, 'admin/auth/permissions/6', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:41:59', '2020-07-30 05:41:59');
INSERT INTO `lms_admin_operation_log` VALUES (130, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:42:05', '2020-07-30 05:42:05');
INSERT INTO `lms_admin_operation_log` VALUES (131, 1, 'admin/auth/permissions/5/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:42:09', '2020-07-30 05:42:09');
INSERT INTO `lms_admin_operation_log` VALUES (132, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:42:13', '2020-07-30 05:42:13');
INSERT INTO `lms_admin_operation_log` VALUES (133, 1, 'admin/auth/permissions/6/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:42:16', '2020-07-30 05:42:16');
INSERT INTO `lms_admin_operation_log` VALUES (134, 1, 'admin/auth/permissions/6', 'PUT', '127.0.0.1', '{\"slug\":\"shops\",\"name\":\"\\u5546\\u5bb6\",\"http_method\":[null],\"http_path\":\"\\/\\r\\n\\/auth\\/login\\r\\n\\/auth\\/logout\\r\\n\\/auth\\/setting\\r\\n\\/products\\r\\n\\/shops\",\"_token\":\"MaJJzbQjlVu5CikOeChZrT6cBMc3Enizg4kB1x6z\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/auth\\/permissions\"}', '2020-07-30 05:42:38', '2020-07-30 05:42:38');
INSERT INTO `lms_admin_operation_log` VALUES (135, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '[]', '2020-07-30 05:42:39', '2020-07-30 05:42:39');
INSERT INTO `lms_admin_operation_log` VALUES (136, 1, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:42:47', '2020-07-30 05:42:47');
INSERT INTO `lms_admin_operation_log` VALUES (137, 2, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-30 05:42:56', '2020-07-30 05:42:56');
INSERT INTO `lms_admin_operation_log` VALUES (138, 2, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:42:58', '2020-07-30 05:42:58');
INSERT INTO `lms_admin_operation_log` VALUES (139, 2, 'admin/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:43:01', '2020-07-30 05:43:01');
INSERT INTO `lms_admin_operation_log` VALUES (140, 2, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:43:02', '2020-07-30 05:43:02');
INSERT INTO `lms_admin_operation_log` VALUES (141, 2, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:43:03', '2020-07-30 05:43:03');
INSERT INTO `lms_admin_operation_log` VALUES (142, 2, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:43:07', '2020-07-30 05:43:07');
INSERT INTO `lms_admin_operation_log` VALUES (143, 1, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-30 05:43:16', '2020-07-30 05:43:16');
INSERT INTO `lms_admin_operation_log` VALUES (144, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:43:20', '2020-07-30 05:43:20');
INSERT INTO `lms_admin_operation_log` VALUES (145, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:46:46', '2020-07-30 05:46:46');
INSERT INTO `lms_admin_operation_log` VALUES (146, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 05:48:43', '2020-07-30 05:48:43');
INSERT INTO `lms_admin_operation_log` VALUES (147, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 07:17:20', '2020-07-30 07:17:20');
INSERT INTO `lms_admin_operation_log` VALUES (148, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 07:22:19', '2020-07-30 07:22:19');
INSERT INTO `lms_admin_operation_log` VALUES (149, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 07:22:21', '2020-07-30 07:22:21');
INSERT INTO `lms_admin_operation_log` VALUES (150, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 07:22:22', '2020-07-30 07:22:22');
INSERT INTO `lms_admin_operation_log` VALUES (151, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 07:25:42', '2020-07-30 07:25:42');
INSERT INTO `lms_admin_operation_log` VALUES (152, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 07:25:43', '2020-07-30 07:25:43');
INSERT INTO `lms_admin_operation_log` VALUES (153, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 07:25:45', '2020-07-30 07:25:45');
INSERT INTO `lms_admin_operation_log` VALUES (154, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 07:30:50', '2020-07-30 07:30:50');
INSERT INTO `lms_admin_operation_log` VALUES (155, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 07:30:51', '2020-07-30 07:30:51');
INSERT INTO `lms_admin_operation_log` VALUES (156, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-30 07:32:34', '2020-07-30 07:32:34');
INSERT INTO `lms_admin_operation_log` VALUES (157, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-30 07:33:29', '2020-07-30 07:33:29');
INSERT INTO `lms_admin_operation_log` VALUES (158, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"shou\"}', '2020-07-30 07:33:45', '2020-07-30 07:33:45');
INSERT INTO `lms_admin_operation_log` VALUES (159, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"shou\'ji\"}', '2020-07-30 07:33:45', '2020-07-30 07:33:45');
INSERT INTO `lms_admin_operation_log` VALUES (160, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\"}', '2020-07-30 07:33:46', '2020-07-30 07:33:46');
INSERT INTO `lms_admin_operation_log` VALUES (161, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\"}', '2020-07-30 07:33:47', '2020-07-30 07:33:47');
INSERT INTO `lms_admin_operation_log` VALUES (162, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-30 07:34:48', '2020-07-30 07:34:48');
INSERT INTO `lms_admin_operation_log` VALUES (163, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 07:38:34', '2020-07-30 07:38:34');
INSERT INTO `lms_admin_operation_log` VALUES (164, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 07:38:37', '2020-07-30 07:38:37');
INSERT INTO `lms_admin_operation_log` VALUES (165, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 07:39:07', '2020-07-30 07:39:07');
INSERT INTO `lms_admin_operation_log` VALUES (166, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-30 07:42:03', '2020-07-30 07:42:03');
INSERT INTO `lms_admin_operation_log` VALUES (167, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-30 07:42:22', '2020-07-30 07:42:22');
INSERT INTO `lms_admin_operation_log` VALUES (168, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-30 07:48:39', '2020-07-30 07:48:39');
INSERT INTO `lms_admin_operation_log` VALUES (169, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 07:48:46', '2020-07-30 07:48:46');
INSERT INTO `lms_admin_operation_log` VALUES (170, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 07:48:48', '2020-07-30 07:48:48');
INSERT INTO `lms_admin_operation_log` VALUES (171, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-30 07:53:45', '2020-07-30 07:53:45');
INSERT INTO `lms_admin_operation_log` VALUES (172, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 07:54:27', '2020-07-30 07:54:27');
INSERT INTO `lms_admin_operation_log` VALUES (173, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 07:54:37', '2020-07-30 07:54:37');
INSERT INTO `lms_admin_operation_log` VALUES (174, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"\\u5e97\\u94fa\\u7ba1\\u7406\",\"icon\":\"fa-shops\",\"uri\":null,\"roles\":[null],\"permission\":null,\"_token\":\"NabahYtPHgFczpJuyj3nrds8slhjBeepVbEw1e4O\"}', '2020-07-30 07:54:49', '2020-07-30 07:54:49');
INSERT INTO `lms_admin_operation_log` VALUES (175, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-30 07:54:50', '2020-07-30 07:54:50');
INSERT INTO `lms_admin_operation_log` VALUES (176, 1, 'admin/auth/menu/12/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 07:54:53', '2020-07-30 07:54:53');
INSERT INTO `lms_admin_operation_log` VALUES (177, 1, 'admin/auth/menu/12', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"\\u5e97\\u94fa\\u7ba1\\u7406\",\"icon\":\"fa-home\",\"uri\":null,\"roles\":[null],\"permission\":null,\"_token\":\"NabahYtPHgFczpJuyj3nrds8slhjBeepVbEw1e4O\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/auth\\/menu\"}', '2020-07-30 07:55:03', '2020-07-30 07:55:03');
INSERT INTO `lms_admin_operation_log` VALUES (178, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-30 07:55:03', '2020-07-30 07:55:03');
INSERT INTO `lms_admin_operation_log` VALUES (179, 1, 'admin/auth/menu/12/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 07:55:07', '2020-07-30 07:55:07');
INSERT INTO `lms_admin_operation_log` VALUES (180, 1, 'admin/auth/menu/12', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"\\u5e97\\u94fa\\u7ba1\\u7406\",\"icon\":\"fa-home\",\"uri\":\"\\/shops\",\"roles\":[null],\"permission\":null,\"_token\":\"NabahYtPHgFczpJuyj3nrds8slhjBeepVbEw1e4O\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/auth\\/menu\"}', '2020-07-30 07:55:16', '2020-07-30 07:55:16');
INSERT INTO `lms_admin_operation_log` VALUES (181, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-30 07:55:16', '2020-07-30 07:55:16');
INSERT INTO `lms_admin_operation_log` VALUES (182, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"_token\":\"NabahYtPHgFczpJuyj3nrds8slhjBeepVbEw1e4O\",\"_order\":\"[{\\\"id\\\":1},{\\\"id\\\":12},{\\\"id\\\":11},{\\\"id\\\":8},{\\\"id\\\":10},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]}]\"}', '2020-07-30 07:55:30', '2020-07-30 07:55:30');
INSERT INTO `lms_admin_operation_log` VALUES (183, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 07:55:31', '2020-07-30 07:55:31');
INSERT INTO `lms_admin_operation_log` VALUES (184, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-30 07:55:37', '2020-07-30 07:55:37');
INSERT INTO `lms_admin_operation_log` VALUES (185, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 07:55:42', '2020-07-30 07:55:42');
INSERT INTO `lms_admin_operation_log` VALUES (186, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 08:01:50', '2020-07-30 08:01:50');
INSERT INTO `lms_admin_operation_log` VALUES (187, 1, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:01:53', '2020-07-30 08:01:53');
INSERT INTO `lms_admin_operation_log` VALUES (188, 1, 'admin/shops', 'GET', '127.0.0.1', '[]', '2020-07-30 08:03:10', '2020-07-30 08:03:10');
INSERT INTO `lms_admin_operation_log` VALUES (189, 1, 'admin/shops/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:03:12', '2020-07-30 08:03:12');
INSERT INTO `lms_admin_operation_log` VALUES (190, 1, 'admin/shops/create', 'GET', '127.0.0.1', '[]', '2020-07-30 08:04:27', '2020-07-30 08:04:27');
INSERT INTO `lms_admin_operation_log` VALUES (191, 1, 'admin/shops', 'POST', '127.0.0.1', '{\"\\u5e97\\u94fa\\u540d\\u79f0\":\"\\u661f\\u7a7a\",\"_token\":\"NabahYtPHgFczpJuyj3nrds8slhjBeepVbEw1e4O\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/shops\"}', '2020-07-30 08:04:55', '2020-07-30 08:04:55');
INSERT INTO `lms_admin_operation_log` VALUES (192, 1, 'admin/shops/create', 'GET', '127.0.0.1', '[]', '2020-07-30 08:04:56', '2020-07-30 08:04:56');
INSERT INTO `lms_admin_operation_log` VALUES (193, 1, 'admin/shops/create', 'GET', '127.0.0.1', '[]', '2020-07-30 08:05:22', '2020-07-30 08:05:22');
INSERT INTO `lms_admin_operation_log` VALUES (194, 1, 'admin/shops', 'POST', '127.0.0.1', '{\"name\":\"\\u661f\\u7a7a\",\"_token\":\"NabahYtPHgFczpJuyj3nrds8slhjBeepVbEw1e4O\"}', '2020-07-30 08:05:28', '2020-07-30 08:05:28');
INSERT INTO `lms_admin_operation_log` VALUES (195, 1, 'admin/shops/create', 'GET', '127.0.0.1', '[]', '2020-07-30 08:05:29', '2020-07-30 08:05:29');
INSERT INTO `lms_admin_operation_log` VALUES (196, 1, 'admin/shops/create', 'GET', '127.0.0.1', '[]', '2020-07-30 08:11:37', '2020-07-30 08:11:37');
INSERT INTO `lms_admin_operation_log` VALUES (197, 1, 'admin/shops', 'POST', '127.0.0.1', '{\"name\":\"\\u661f\\u7a7a\",\"_token\":\"NabahYtPHgFczpJuyj3nrds8slhjBeepVbEw1e4O\"}', '2020-07-30 08:11:42', '2020-07-30 08:11:42');
INSERT INTO `lms_admin_operation_log` VALUES (198, 1, 'admin/shops', 'GET', '127.0.0.1', '[]', '2020-07-30 08:11:42', '2020-07-30 08:11:42');
INSERT INTO `lms_admin_operation_log` VALUES (199, 1, 'admin/shops', 'GET', '127.0.0.1', '[]', '2020-07-30 08:14:12', '2020-07-30 08:14:12');
INSERT INTO `lms_admin_operation_log` VALUES (200, 1, 'admin/shops/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:14:15', '2020-07-30 08:14:15');
INSERT INTO `lms_admin_operation_log` VALUES (201, 1, 'admin/shops/create', 'GET', '127.0.0.1', '[]', '2020-07-30 08:14:35', '2020-07-30 08:14:35');
INSERT INTO `lms_admin_operation_log` VALUES (202, 1, 'admin/shops', 'GET', '127.0.0.1', '[]', '2020-07-30 08:15:00', '2020-07-30 08:15:00');
INSERT INTO `lms_admin_operation_log` VALUES (203, 1, 'admin/shops/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:15:02', '2020-07-30 08:15:02');
INSERT INTO `lms_admin_operation_log` VALUES (204, 1, 'admin/shops', 'POST', '127.0.0.1', '{\"name\":\"harry\",\"_token\":\"NabahYtPHgFczpJuyj3nrds8slhjBeepVbEw1e4O\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/shops\"}', '2020-07-30 08:15:08', '2020-07-30 08:15:08');
INSERT INTO `lms_admin_operation_log` VALUES (205, 1, 'admin/shops', 'GET', '127.0.0.1', '[]', '2020-07-30 08:15:08', '2020-07-30 08:15:08');
INSERT INTO `lms_admin_operation_log` VALUES (206, 1, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:15:47', '2020-07-30 08:15:47');
INSERT INTO `lms_admin_operation_log` VALUES (207, 2, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-30 08:16:01', '2020-07-30 08:16:01');
INSERT INTO `lms_admin_operation_log` VALUES (208, 2, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:16:04', '2020-07-30 08:16:04');
INSERT INTO `lms_admin_operation_log` VALUES (209, 2, 'admin/shops', 'GET', '127.0.0.1', '[]', '2020-07-30 08:24:42', '2020-07-30 08:24:42');
INSERT INTO `lms_admin_operation_log` VALUES (210, 2, 'admin/shops', 'GET', '127.0.0.1', '[]', '2020-07-30 08:31:13', '2020-07-30 08:31:13');
INSERT INTO `lms_admin_operation_log` VALUES (211, 2, 'admin/shops', 'GET', '127.0.0.1', '[]', '2020-07-30 08:31:16', '2020-07-30 08:31:16');
INSERT INTO `lms_admin_operation_log` VALUES (212, 2, 'admin/shops', 'GET', '127.0.0.1', '[]', '2020-07-30 08:35:10', '2020-07-30 08:35:10');
INSERT INTO `lms_admin_operation_log` VALUES (213, 2, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:35:17', '2020-07-30 08:35:17');
INSERT INTO `lms_admin_operation_log` VALUES (214, 1, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-30 08:35:24', '2020-07-30 08:35:24');
INSERT INTO `lms_admin_operation_log` VALUES (215, 1, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:35:29', '2020-07-30 08:35:29');
INSERT INTO `lms_admin_operation_log` VALUES (216, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:35:54', '2020-07-30 08:35:54');
INSERT INTO `lms_admin_operation_log` VALUES (217, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 08:41:14', '2020-07-30 08:41:14');
INSERT INTO `lms_admin_operation_log` VALUES (218, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 08:48:17', '2020-07-30 08:48:17');
INSERT INTO `lms_admin_operation_log` VALUES (219, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:49:13', '2020-07-30 08:49:13');
INSERT INTO `lms_admin_operation_log` VALUES (220, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 08:53:50', '2020-07-30 08:53:50');
INSERT INTO `lms_admin_operation_log` VALUES (221, 1, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:54:28', '2020-07-30 08:54:28');
INSERT INTO `lms_admin_operation_log` VALUES (222, 2, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-30 08:54:45', '2020-07-30 08:54:45');
INSERT INTO `lms_admin_operation_log` VALUES (223, 2, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:54:48', '2020-07-30 08:54:48');
INSERT INTO `lms_admin_operation_log` VALUES (224, 2, 'admin/shops/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:54:52', '2020-07-30 08:54:52');
INSERT INTO `lms_admin_operation_log` VALUES (225, 2, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:55:03', '2020-07-30 08:55:03');
INSERT INTO `lms_admin_operation_log` VALUES (226, 1, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-30 08:55:10', '2020-07-30 08:55:10');
INSERT INTO `lms_admin_operation_log` VALUES (227, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:55:13', '2020-07-30 08:55:13');
INSERT INTO `lms_admin_operation_log` VALUES (228, 1, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:55:14', '2020-07-30 08:55:14');
INSERT INTO `lms_admin_operation_log` VALUES (229, 1, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:55:15', '2020-07-30 08:55:15');
INSERT INTO `lms_admin_operation_log` VALUES (230, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:55:17', '2020-07-30 08:55:17');
INSERT INTO `lms_admin_operation_log` VALUES (231, 1, 'admin/auth/permissions/6/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:55:22', '2020-07-30 08:55:22');
INSERT INTO `lms_admin_operation_log` VALUES (232, 1, 'admin/auth/permissions/6', 'PUT', '127.0.0.1', '{\"slug\":\"shops\",\"name\":\"\\u5546\\u5bb6\",\"http_method\":[null],\"http_path\":\"\\/\\r\\n\\/auth\\/login\\r\\n\\/auth\\/logout\\r\\n\\/auth\\/setting\\r\\n\\/products\\r\\n\\/shops\\r\\n\\/shops\\/create\\r\\n\\/shops\\/update\",\"_token\":\"shxlFTJq0I7eC5KFDCHAi1I7s9GKVDw90eVEh6XP\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/auth\\/permissions\"}', '2020-07-30 08:55:46', '2020-07-30 08:55:46');
INSERT INTO `lms_admin_operation_log` VALUES (233, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '[]', '2020-07-30 08:55:46', '2020-07-30 08:55:46');
INSERT INTO `lms_admin_operation_log` VALUES (234, 1, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:55:53', '2020-07-30 08:55:53');
INSERT INTO `lms_admin_operation_log` VALUES (235, 2, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-30 08:56:02', '2020-07-30 08:56:02');
INSERT INTO `lms_admin_operation_log` VALUES (236, 2, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:56:05', '2020-07-30 08:56:05');
INSERT INTO `lms_admin_operation_log` VALUES (237, 2, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:56:06', '2020-07-30 08:56:06');
INSERT INTO `lms_admin_operation_log` VALUES (238, 2, 'admin/shops/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:56:08', '2020-07-30 08:56:08');
INSERT INTO `lms_admin_operation_log` VALUES (239, 2, 'admin/shops', 'POST', '127.0.0.1', '{\"name\":\"\\u661f\\u7a7a\",\"_token\":\"FjVUQvuHpIqGzWAGn4XPK8h7zPlfJ1RbY7sZmEwU\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/shops\"}', '2020-07-30 08:56:16', '2020-07-30 08:56:16');
INSERT INTO `lms_admin_operation_log` VALUES (240, 2, 'admin/shops', 'GET', '127.0.0.1', '[]', '2020-07-30 08:56:16', '2020-07-30 08:56:16');
INSERT INTO `lms_admin_operation_log` VALUES (241, 2, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:56:22', '2020-07-30 08:56:22');
INSERT INTO `lms_admin_operation_log` VALUES (242, 2, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:56:24', '2020-07-30 08:56:24');
INSERT INTO `lms_admin_operation_log` VALUES (243, 2, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:56:32', '2020-07-30 08:56:32');
INSERT INTO `lms_admin_operation_log` VALUES (244, 1, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-30 08:56:38', '2020-07-30 08:56:38');
INSERT INTO `lms_admin_operation_log` VALUES (245, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:56:44', '2020-07-30 08:56:44');
INSERT INTO `lms_admin_operation_log` VALUES (246, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:56:49', '2020-07-30 08:56:49');
INSERT INTO `lms_admin_operation_log` VALUES (247, 1, 'admin/auth/permissions/6/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:56:52', '2020-07-30 08:56:52');
INSERT INTO `lms_admin_operation_log` VALUES (248, 1, 'admin/auth/permissions/6', 'PUT', '127.0.0.1', '{\"slug\":\"shops\",\"name\":\"\\u5546\\u5bb6\",\"http_method\":[null],\"http_path\":\"\\/\\r\\n\\/auth\\/login\\r\\n\\/auth\\/logout\\r\\n\\/auth\\/setting\\r\\n\\/products\\/*\\r\\n\\/shops\\r\\n\\/shops\\/create\\r\\n\\/shops\\/update\",\"_token\":\"9SJSc4sMoCuJbFKUWLDrIbrmdDSHey4a7XHKjEIS\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/auth\\/permissions\"}', '2020-07-30 08:57:05', '2020-07-30 08:57:05');
INSERT INTO `lms_admin_operation_log` VALUES (249, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '[]', '2020-07-30 08:57:05', '2020-07-30 08:57:05');
INSERT INTO `lms_admin_operation_log` VALUES (250, 1, 'admin/auth/permissions/6/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:57:09', '2020-07-30 08:57:09');
INSERT INTO `lms_admin_operation_log` VALUES (251, 1, 'admin/auth/permissions/6', 'PUT', '127.0.0.1', '{\"slug\":\"shops\",\"name\":\"\\u5546\\u5bb6\",\"http_method\":[null],\"http_path\":\"\\/\\r\\n\\/auth\\/login\\r\\n\\/auth\\/logout\\r\\n\\/auth\\/setting\\r\\n\\/products*\\r\\n\\/shops*\",\"_token\":\"9SJSc4sMoCuJbFKUWLDrIbrmdDSHey4a7XHKjEIS\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/auth\\/permissions\"}', '2020-07-30 08:57:21', '2020-07-30 08:57:21');
INSERT INTO `lms_admin_operation_log` VALUES (252, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '[]', '2020-07-30 08:57:21', '2020-07-30 08:57:21');
INSERT INTO `lms_admin_operation_log` VALUES (253, 1, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:57:28', '2020-07-30 08:57:28');
INSERT INTO `lms_admin_operation_log` VALUES (254, 2, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-30 08:57:36', '2020-07-30 08:57:36');
INSERT INTO `lms_admin_operation_log` VALUES (255, 2, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:57:39', '2020-07-30 08:57:39');
INSERT INTO `lms_admin_operation_log` VALUES (256, 2, 'admin/shops/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:57:40', '2020-07-30 08:57:40');
INSERT INTO `lms_admin_operation_log` VALUES (257, 2, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:57:42', '2020-07-30 08:57:42');
INSERT INTO `lms_admin_operation_log` VALUES (258, 2, 'admin/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:57:45', '2020-07-30 08:57:45');
INSERT INTO `lms_admin_operation_log` VALUES (259, 2, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:57:47', '2020-07-30 08:57:47');
INSERT INTO `lms_admin_operation_log` VALUES (260, 2, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:57:52', '2020-07-30 08:57:52');
INSERT INTO `lms_admin_operation_log` VALUES (261, 2, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:57:53', '2020-07-30 08:57:53');
INSERT INTO `lms_admin_operation_log` VALUES (262, 2, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:57:58', '2020-07-30 08:57:58');
INSERT INTO `lms_admin_operation_log` VALUES (263, 1, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-30 08:58:05', '2020-07-30 08:58:05');
INSERT INTO `lms_admin_operation_log` VALUES (264, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:58:10', '2020-07-30 08:58:10');
INSERT INTO `lms_admin_operation_log` VALUES (265, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:58:18', '2020-07-30 08:58:18');
INSERT INTO `lms_admin_operation_log` VALUES (266, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:58:20', '2020-07-30 08:58:20');
INSERT INTO `lms_admin_operation_log` VALUES (267, 1, 'admin/auth/roles/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:58:24', '2020-07-30 08:58:24');
INSERT INTO `lms_admin_operation_log` VALUES (268, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:58:37', '2020-07-30 08:58:37');
INSERT INTO `lms_admin_operation_log` VALUES (269, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:58:42', '2020-07-30 08:58:42');
INSERT INTO `lms_admin_operation_log` VALUES (270, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:58:50', '2020-07-30 08:58:50');
INSERT INTO `lms_admin_operation_log` VALUES (271, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:58:56', '2020-07-30 08:58:56');
INSERT INTO `lms_admin_operation_log` VALUES (272, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:59:01', '2020-07-30 08:59:01');
INSERT INTO `lms_admin_operation_log` VALUES (273, 1, 'admin/auth/menu/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:59:04', '2020-07-30 08:59:04');
INSERT INTO `lms_admin_operation_log` VALUES (274, 1, 'admin/auth/menu/1', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Dashboard\",\"icon\":\"fa-bar-chart\",\"uri\":\"\\/\",\"roles\":[null],\"permission\":null,\"_token\":\"hIUmQ4wBPUWCiW02gZgmdtZBbMObKMylHOmmZa4o\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/auth\\/menu\"}', '2020-07-30 08:59:17', '2020-07-30 08:59:17');
INSERT INTO `lms_admin_operation_log` VALUES (275, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-30 08:59:17', '2020-07-30 08:59:17');
INSERT INTO `lms_admin_operation_log` VALUES (276, 1, 'admin/auth/menu/12/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:59:22', '2020-07-30 08:59:22');
INSERT INTO `lms_admin_operation_log` VALUES (277, 1, 'admin/auth/menu/12', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"\\u5e97\\u94fa\\u7ba1\\u7406\",\"icon\":\"fa-home\",\"uri\":\"\\/shops\",\"roles\":[\"1\",\"2\",null],\"permission\":null,\"_token\":\"hIUmQ4wBPUWCiW02gZgmdtZBbMObKMylHOmmZa4o\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/auth\\/menu\"}', '2020-07-30 08:59:36', '2020-07-30 08:59:36');
INSERT INTO `lms_admin_operation_log` VALUES (278, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-30 08:59:37', '2020-07-30 08:59:37');
INSERT INTO `lms_admin_operation_log` VALUES (279, 1, 'admin/auth/menu/11/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:59:40', '2020-07-30 08:59:40');
INSERT INTO `lms_admin_operation_log` VALUES (280, 1, 'admin/auth/menu/11', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"\\u5546\\u54c1\\u7ba1\\u7406\",\"icon\":\"fa-cubes\",\"uri\":\"\\/products\",\"roles\":[\"1\",\"2\",null],\"permission\":null,\"_token\":\"hIUmQ4wBPUWCiW02gZgmdtZBbMObKMylHOmmZa4o\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/auth\\/menu\"}', '2020-07-30 08:59:45', '2020-07-30 08:59:45');
INSERT INTO `lms_admin_operation_log` VALUES (281, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-30 08:59:45', '2020-07-30 08:59:45');
INSERT INTO `lms_admin_operation_log` VALUES (282, 1, 'admin/auth/menu/8/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:59:49', '2020-07-30 08:59:49');
INSERT INTO `lms_admin_operation_log` VALUES (283, 1, 'admin/auth/menu/8', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"fa-users\",\"uri\":\"\\/users\",\"roles\":[\"1\",null],\"permission\":null,\"_token\":\"hIUmQ4wBPUWCiW02gZgmdtZBbMObKMylHOmmZa4o\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/auth\\/menu\"}', '2020-07-30 08:59:52', '2020-07-30 08:59:52');
INSERT INTO `lms_admin_operation_log` VALUES (284, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-30 08:59:53', '2020-07-30 08:59:53');
INSERT INTO `lms_admin_operation_log` VALUES (285, 1, 'admin/auth/menu/10/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 08:59:56', '2020-07-30 08:59:56');
INSERT INTO `lms_admin_operation_log` VALUES (286, 1, 'admin/auth/menu/10', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"\\u5206\\u7c7b\\u7ba1\\u7406\",\"icon\":\"fa-bars\",\"uri\":\"\\/categories\",\"roles\":[\"1\",null],\"permission\":null,\"_token\":\"hIUmQ4wBPUWCiW02gZgmdtZBbMObKMylHOmmZa4o\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/auth\\/menu\"}', '2020-07-30 08:59:59', '2020-07-30 08:59:59');
INSERT INTO `lms_admin_operation_log` VALUES (287, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-30 08:59:59', '2020-07-30 08:59:59');
INSERT INTO `lms_admin_operation_log` VALUES (288, 1, 'admin/auth/menu/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 09:00:03', '2020-07-30 09:00:03');
INSERT INTO `lms_admin_operation_log` VALUES (289, 1, 'admin/auth/menu/2', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Admin\",\"icon\":\"fa-tasks\",\"uri\":null,\"roles\":[\"1\",null],\"permission\":null,\"_token\":\"hIUmQ4wBPUWCiW02gZgmdtZBbMObKMylHOmmZa4o\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/auth\\/menu\"}', '2020-07-30 09:00:05', '2020-07-30 09:00:05');
INSERT INTO `lms_admin_operation_log` VALUES (290, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2020-07-30 09:00:05', '2020-07-30 09:00:05');
INSERT INTO `lms_admin_operation_log` VALUES (291, 1, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 09:00:11', '2020-07-30 09:00:11');
INSERT INTO `lms_admin_operation_log` VALUES (292, 2, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-30 09:00:23', '2020-07-30 09:00:23');
INSERT INTO `lms_admin_operation_log` VALUES (293, 2, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 09:00:28', '2020-07-30 09:00:28');
INSERT INTO `lms_admin_operation_log` VALUES (294, 2, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 09:00:29', '2020-07-30 09:00:29');
INSERT INTO `lms_admin_operation_log` VALUES (295, 2, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 09:02:53', '2020-07-30 09:02:53');
INSERT INTO `lms_admin_operation_log` VALUES (296, 2, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 12:28:54', '2020-07-30 12:28:54');
INSERT INTO `lms_admin_operation_log` VALUES (297, 2, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 12:28:57', '2020-07-30 12:28:57');
INSERT INTO `lms_admin_operation_log` VALUES (298, 2, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 12:29:30', '2020-07-30 12:29:30');
INSERT INTO `lms_admin_operation_log` VALUES (299, 2, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 12:30:07', '2020-07-30 12:30:07');
INSERT INTO `lms_admin_operation_log` VALUES (300, 2, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 12:31:30', '2020-07-30 12:31:30');
INSERT INTO `lms_admin_operation_log` VALUES (301, 2, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-30 12:35:00', '2020-07-30 12:35:00');
INSERT INTO `lms_admin_operation_log` VALUES (302, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\",\"_pjax\":\"#pjax-container\"}', '2020-07-30 12:35:09', '2020-07-30 12:35:09');
INSERT INTO `lms_admin_operation_log` VALUES (303, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\"}', '2020-07-30 12:37:06', '2020-07-30 12:37:06');
INSERT INTO `lms_admin_operation_log` VALUES (304, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\"}', '2020-07-30 12:37:51', '2020-07-30 12:37:51');
INSERT INTO `lms_admin_operation_log` VALUES (305, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\"}', '2020-07-30 12:38:37', '2020-07-30 12:38:37');
INSERT INTO `lms_admin_operation_log` VALUES (306, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\"}', '2020-07-30 12:39:38', '2020-07-30 12:39:38');
INSERT INTO `lms_admin_operation_log` VALUES (307, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\"}', '2020-07-30 12:49:54', '2020-07-30 12:49:54');
INSERT INTO `lms_admin_operation_log` VALUES (308, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\"}', '2020-07-30 12:51:49', '2020-07-30 12:51:49');
INSERT INTO `lms_admin_operation_log` VALUES (309, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\"}', '2020-07-30 12:52:21', '2020-07-30 12:52:21');
INSERT INTO `lms_admin_operation_log` VALUES (310, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\"}', '2020-07-30 12:52:38', '2020-07-30 12:52:38');
INSERT INTO `lms_admin_operation_log` VALUES (311, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\"}', '2020-07-30 12:52:49', '2020-07-30 12:52:49');
INSERT INTO `lms_admin_operation_log` VALUES (312, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\"}', '2020-07-30 12:53:08', '2020-07-30 12:53:08');
INSERT INTO `lms_admin_operation_log` VALUES (313, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\"}', '2020-07-30 12:53:20', '2020-07-30 12:53:20');
INSERT INTO `lms_admin_operation_log` VALUES (314, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\"}', '2020-07-30 12:53:59', '2020-07-30 12:53:59');
INSERT INTO `lms_admin_operation_log` VALUES (315, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\"}', '2020-07-30 12:54:20', '2020-07-30 12:54:20');
INSERT INTO `lms_admin_operation_log` VALUES (316, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\"}', '2020-07-30 12:55:03', '2020-07-30 12:55:03');
INSERT INTO `lms_admin_operation_log` VALUES (317, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\",\"page\":\"2\",\"_pjax\":\"#pjax-container\"}', '2020-07-30 12:55:10', '2020-07-30 12:55:10');
INSERT INTO `lms_admin_operation_log` VALUES (318, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\",\"_pjax\":\"#pjax-container\",\"page\":\"3\"}', '2020-07-30 12:55:12', '2020-07-30 12:55:12');
INSERT INTO `lms_admin_operation_log` VALUES (319, 2, 'admin/products', 'GET', '127.0.0.1', '{\"per_page\":\"10\",\"_pjax\":\"#pjax-container\",\"page\":\"1\"}', '2020-07-30 12:55:14', '2020-07-30 12:55:14');
INSERT INTO `lms_admin_operation_log` VALUES (320, 2, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 12:55:34', '2020-07-30 12:55:34');
INSERT INTO `lms_admin_operation_log` VALUES (321, 2, 'admin/shops/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 12:55:36', '2020-07-30 12:55:36');
INSERT INTO `lms_admin_operation_log` VALUES (322, 2, 'admin/shops', 'POST', '127.0.0.1', '{\"name\":\"will\",\"_token\":\"dwaUQjaZQLXnznymAdcAJL38HRJZP5mSq99mbMZ0\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/shops\"}', '2020-07-30 12:55:41', '2020-07-30 12:55:41');
INSERT INTO `lms_admin_operation_log` VALUES (323, 2, 'admin/shops', 'GET', '127.0.0.1', '[]', '2020-07-30 12:55:41', '2020-07-30 12:55:41');
INSERT INTO `lms_admin_operation_log` VALUES (324, 2, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-30 12:56:08', '2020-07-30 12:56:08');
INSERT INTO `lms_admin_operation_log` VALUES (325, 2, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\",\"page\":\"2\"}', '2020-07-30 12:56:16', '2020-07-30 12:56:16');
INSERT INTO `lms_admin_operation_log` VALUES (326, 2, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\",\"page\":\"1\"}', '2020-07-30 12:56:18', '2020-07-30 12:56:18');
INSERT INTO `lms_admin_operation_log` VALUES (327, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 12:56:56', '2020-07-30 12:56:56');
INSERT INTO `lms_admin_operation_log` VALUES (328, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:01:40', '2020-07-30 13:01:40');
INSERT INTO `lms_admin_operation_log` VALUES (329, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:02:17', '2020-07-30 13:02:17');
INSERT INTO `lms_admin_operation_log` VALUES (330, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:04:24', '2020-07-30 13:04:24');
INSERT INTO `lms_admin_operation_log` VALUES (331, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:05:18', '2020-07-30 13:05:18');
INSERT INTO `lms_admin_operation_log` VALUES (332, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:05:55', '2020-07-30 13:05:55');
INSERT INTO `lms_admin_operation_log` VALUES (333, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:06:19', '2020-07-30 13:06:19');
INSERT INTO `lms_admin_operation_log` VALUES (334, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:07:57', '2020-07-30 13:07:57');
INSERT INTO `lms_admin_operation_log` VALUES (335, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:08:11', '2020-07-30 13:08:11');
INSERT INTO `lms_admin_operation_log` VALUES (336, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:08:28', '2020-07-30 13:08:28');
INSERT INTO `lms_admin_operation_log` VALUES (337, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:08:58', '2020-07-30 13:08:58');
INSERT INTO `lms_admin_operation_log` VALUES (338, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:09:51', '2020-07-30 13:09:51');
INSERT INTO `lms_admin_operation_log` VALUES (339, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:10:19', '2020-07-30 13:10:19');
INSERT INTO `lms_admin_operation_log` VALUES (340, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:11:30', '2020-07-30 13:11:30');
INSERT INTO `lms_admin_operation_log` VALUES (341, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:11:52', '2020-07-30 13:11:52');
INSERT INTO `lms_admin_operation_log` VALUES (342, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:12:20', '2020-07-30 13:12:20');
INSERT INTO `lms_admin_operation_log` VALUES (343, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:15:27', '2020-07-30 13:15:27');
INSERT INTO `lms_admin_operation_log` VALUES (344, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:15:43', '2020-07-30 13:15:43');
INSERT INTO `lms_admin_operation_log` VALUES (345, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:16:07', '2020-07-30 13:16:07');
INSERT INTO `lms_admin_operation_log` VALUES (346, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:16:20', '2020-07-30 13:16:20');
INSERT INTO `lms_admin_operation_log` VALUES (347, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:17:39', '2020-07-30 13:17:39');
INSERT INTO `lms_admin_operation_log` VALUES (348, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:20:08', '2020-07-30 13:20:08');
INSERT INTO `lms_admin_operation_log` VALUES (349, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:20:32', '2020-07-30 13:20:32');
INSERT INTO `lms_admin_operation_log` VALUES (350, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:20:45', '2020-07-30 13:20:45');
INSERT INTO `lms_admin_operation_log` VALUES (351, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:21:14', '2020-07-30 13:21:14');
INSERT INTO `lms_admin_operation_log` VALUES (352, 2, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"1\"}', '2020-07-30 13:21:41', '2020-07-30 13:21:41');
INSERT INTO `lms_admin_operation_log` VALUES (353, 2, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-31 05:16:28', '2020-07-31 05:16:28');
INSERT INTO `lms_admin_operation_log` VALUES (354, 2, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-31 05:18:13', '2020-07-31 05:18:13');
INSERT INTO `lms_admin_operation_log` VALUES (355, 2, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-31 05:18:17', '2020-07-31 05:18:17');
INSERT INTO `lms_admin_operation_log` VALUES (356, 2, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-31 05:19:51', '2020-07-31 05:19:51');
INSERT INTO `lms_admin_operation_log` VALUES (357, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:21:17', '2020-07-31 05:21:17');
INSERT INTO `lms_admin_operation_log` VALUES (358, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:21:18', '2020-07-31 05:21:18');
INSERT INTO `lms_admin_operation_log` VALUES (359, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\"}', '2020-07-31 05:21:19', '2020-07-31 05:21:19');
INSERT INTO `lms_admin_operation_log` VALUES (360, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\"}', '2020-07-31 05:21:21', '2020-07-31 05:21:21');
INSERT INTO `lms_admin_operation_log` VALUES (361, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\\u914d\\u7f6e\"}', '2020-07-31 05:21:22', '2020-07-31 05:21:22');
INSERT INTO `lms_admin_operation_log` VALUES (362, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\\u914d\"}', '2020-07-31 05:21:22', '2020-07-31 05:21:22');
INSERT INTO `lms_admin_operation_log` VALUES (363, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\"}', '2020-07-31 05:21:23', '2020-07-31 05:21:23');
INSERT INTO `lms_admin_operation_log` VALUES (364, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\"}', '2020-07-31 05:21:23', '2020-07-31 05:21:23');
INSERT INTO `lms_admin_operation_log` VALUES (365, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\"}', '2020-07-31 05:21:24', '2020-07-31 05:21:24');
INSERT INTO `lms_admin_operation_log` VALUES (366, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:21:24', '2020-07-31 05:21:24');
INSERT INTO `lms_admin_operation_log` VALUES (367, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:21:25', '2020-07-31 05:21:25');
INSERT INTO `lms_admin_operation_log` VALUES (368, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u8033\\u673a\"}', '2020-07-31 05:21:25', '2020-07-31 05:21:25');
INSERT INTO `lms_admin_operation_log` VALUES (369, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u8033\"}', '2020-07-31 05:21:29', '2020-07-31 05:21:29');
INSERT INTO `lms_admin_operation_log` VALUES (370, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:21:34', '2020-07-31 05:21:34');
INSERT INTO `lms_admin_operation_log` VALUES (371, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:21:35', '2020-07-31 05:21:35');
INSERT INTO `lms_admin_operation_log` VALUES (372, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:21:38', '2020-07-31 05:21:38');
INSERT INTO `lms_admin_operation_log` VALUES (373, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:21:38', '2020-07-31 05:21:38');
INSERT INTO `lms_admin_operation_log` VALUES (374, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u8033\\u673a\"}', '2020-07-31 05:21:38', '2020-07-31 05:21:38');
INSERT INTO `lms_admin_operation_log` VALUES (375, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u8033\"}', '2020-07-31 05:21:42', '2020-07-31 05:21:42');
INSERT INTO `lms_admin_operation_log` VALUES (376, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:21:43', '2020-07-31 05:21:43');
INSERT INTO `lms_admin_operation_log` VALUES (377, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:21:43', '2020-07-31 05:21:43');
INSERT INTO `lms_admin_operation_log` VALUES (378, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:21:44', '2020-07-31 05:21:44');
INSERT INTO `lms_admin_operation_log` VALUES (379, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:21:44', '2020-07-31 05:21:44');
INSERT INTO `lms_admin_operation_log` VALUES (380, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u84dd\\u7259\"}', '2020-07-31 05:21:45', '2020-07-31 05:21:45');
INSERT INTO `lms_admin_operation_log` VALUES (381, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u84dd\\u7259\\u8033\\u673a\"}', '2020-07-31 05:21:47', '2020-07-31 05:21:47');
INSERT INTO `lms_admin_operation_log` VALUES (382, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:21:54', '2020-07-31 05:21:54');
INSERT INTO `lms_admin_operation_log` VALUES (383, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:21:57', '2020-07-31 05:21:57');
INSERT INTO `lms_admin_operation_log` VALUES (384, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\"}', '2020-07-31 05:21:57', '2020-07-31 05:21:57');
INSERT INTO `lms_admin_operation_log` VALUES (385, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:23:16', '2020-07-31 05:23:16');
INSERT INTO `lms_admin_operation_log` VALUES (386, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\"}', '2020-07-31 05:23:17', '2020-07-31 05:23:17');
INSERT INTO `lms_admin_operation_log` VALUES (387, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\"}', '2020-07-31 05:23:20', '2020-07-31 05:23:20');
INSERT INTO `lms_admin_operation_log` VALUES (388, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 05:24:36', '2020-07-31 05:24:36');
INSERT INTO `lms_admin_operation_log` VALUES (389, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 05:24:42', '2020-07-31 05:24:42');
INSERT INTO `lms_admin_operation_log` VALUES (390, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:24:58', '2020-07-31 05:24:58');
INSERT INTO `lms_admin_operation_log` VALUES (391, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:24:58', '2020-07-31 05:24:58');
INSERT INTO `lms_admin_operation_log` VALUES (392, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:24:59', '2020-07-31 05:24:59');
INSERT INTO `lms_admin_operation_log` VALUES (393, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:25:00', '2020-07-31 05:25:00');
INSERT INTO `lms_admin_operation_log` VALUES (394, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:25:00', '2020-07-31 05:25:00');
INSERT INTO `lms_admin_operation_log` VALUES (395, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\"}', '2020-07-31 05:25:00', '2020-07-31 05:25:00');
INSERT INTO `lms_admin_operation_log` VALUES (396, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\"}', '2020-07-31 05:25:03', '2020-07-31 05:25:03');
INSERT INTO `lms_admin_operation_log` VALUES (397, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\"}', '2020-07-31 05:25:05', '2020-07-31 05:25:05');
INSERT INTO `lms_admin_operation_log` VALUES (398, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\"}', '2020-07-31 05:25:06', '2020-07-31 05:25:06');
INSERT INTO `lms_admin_operation_log` VALUES (399, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\\u914d\\u7f6e\"}', '2020-07-31 05:25:07', '2020-07-31 05:25:07');
INSERT INTO `lms_admin_operation_log` VALUES (400, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\\u914d\\u7f6e-\"}', '2020-07-31 05:25:09', '2020-07-31 05:25:09');
INSERT INTO `lms_admin_operation_log` VALUES (401, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\\u914d\\u7f6e\"}', '2020-07-31 05:25:11', '2020-07-31 05:25:11');
INSERT INTO `lms_admin_operation_log` VALUES (402, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\"}', '2020-07-31 05:25:12', '2020-07-31 05:25:12');
INSERT INTO `lms_admin_operation_log` VALUES (403, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 05:30:29', '2020-07-31 05:30:29');
INSERT INTO `lms_admin_operation_log` VALUES (404, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 05:30:32', '2020-07-31 05:30:32');
INSERT INTO `lms_admin_operation_log` VALUES (405, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:30:50', '2020-07-31 05:30:50');
INSERT INTO `lms_admin_operation_log` VALUES (406, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u7334\\u6025\"}', '2020-07-31 05:30:50', '2020-07-31 05:30:50');
INSERT INTO `lms_admin_operation_log` VALUES (407, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u7334\"}', '2020-07-31 05:30:50', '2020-07-31 05:30:50');
INSERT INTO `lms_admin_operation_log` VALUES (408, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:30:51', '2020-07-31 05:30:51');
INSERT INTO `lms_admin_operation_log` VALUES (409, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:30:52', '2020-07-31 05:30:52');
INSERT INTO `lms_admin_operation_log` VALUES (410, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\"}', '2020-07-31 05:30:52', '2020-07-31 05:30:52');
INSERT INTO `lms_admin_operation_log` VALUES (411, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\\u53f7\\u7801\"}', '2020-07-31 05:30:55', '2020-07-31 05:30:55');
INSERT INTO `lms_admin_operation_log` VALUES (412, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\\u53f7\"}', '2020-07-31 05:30:57', '2020-07-31 05:30:57');
INSERT INTO `lms_admin_operation_log` VALUES (413, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\\u673a\"}', '2020-07-31 05:30:57', '2020-07-31 05:30:57');
INSERT INTO `lms_admin_operation_log` VALUES (414, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":null}', '2020-07-31 05:30:58', '2020-07-31 05:30:58');
INSERT INTO `lms_admin_operation_log` VALUES (415, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u624b\"}', '2020-07-31 05:30:58', '2020-07-31 05:30:58');
INSERT INTO `lms_admin_operation_log` VALUES (416, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u8033\\u673a\"}', '2020-07-31 05:31:00', '2020-07-31 05:31:00');
INSERT INTO `lms_admin_operation_log` VALUES (417, 2, 'admin/api/categories', 'GET', '127.0.0.1', '{\"q\":\"\\u8033\"}', '2020-07-31 05:31:02', '2020-07-31 05:31:02');
INSERT INTO `lms_admin_operation_log` VALUES (418, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 05:53:44', '2020-07-31 05:53:44');
INSERT INTO `lms_admin_operation_log` VALUES (419, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 05:53:48', '2020-07-31 05:53:48');
INSERT INTO `lms_admin_operation_log` VALUES (420, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 05:54:14', '2020-07-31 05:54:14');
INSERT INTO `lms_admin_operation_log` VALUES (421, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 05:55:29', '2020-07-31 05:55:29');
INSERT INTO `lms_admin_operation_log` VALUES (422, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 05:56:05', '2020-07-31 05:56:05');
INSERT INTO `lms_admin_operation_log` VALUES (423, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 05:56:45', '2020-07-31 05:56:45');
INSERT INTO `lms_admin_operation_log` VALUES (424, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 05:57:24', '2020-07-31 05:57:24');
INSERT INTO `lms_admin_operation_log` VALUES (425, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 05:58:26', '2020-07-31 05:58:26');
INSERT INTO `lms_admin_operation_log` VALUES (426, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 06:54:07', '2020-07-31 06:54:07');
INSERT INTO `lms_admin_operation_log` VALUES (427, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 06:54:54', '2020-07-31 06:54:54');
INSERT INTO `lms_admin_operation_log` VALUES (428, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 06:56:36', '2020-07-31 06:56:36');
INSERT INTO `lms_admin_operation_log` VALUES (429, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 06:57:36', '2020-07-31 06:57:36');
INSERT INTO `lms_admin_operation_log` VALUES (430, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 06:59:59', '2020-07-31 06:59:59');
INSERT INTO `lms_admin_operation_log` VALUES (431, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 07:01:35', '2020-07-31 07:01:35');
INSERT INTO `lms_admin_operation_log` VALUES (432, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 07:02:56', '2020-07-31 07:02:56');
INSERT INTO `lms_admin_operation_log` VALUES (433, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 07:03:40', '2020-07-31 07:03:40');
INSERT INTO `lms_admin_operation_log` VALUES (434, 2, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 07:05:08', '2020-07-31 07:05:08');
INSERT INTO `lms_admin_operation_log` VALUES (435, 2, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-31 07:48:10', '2020-07-31 07:48:10');
INSERT INTO `lms_admin_operation_log` VALUES (436, 1, 'admin', 'GET', '127.0.0.1', '[]', '2020-07-31 07:48:17', '2020-07-31 07:48:17');
INSERT INTO `lms_admin_operation_log` VALUES (437, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-31 07:48:20', '2020-07-31 07:48:20');
INSERT INTO `lms_admin_operation_log` VALUES (438, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-31 07:48:24', '2020-07-31 07:48:24');
INSERT INTO `lms_admin_operation_log` VALUES (439, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 07:57:33', '2020-07-31 07:57:33');
INSERT INTO `lms_admin_operation_log` VALUES (440, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 07:58:16', '2020-07-31 07:58:16');
INSERT INTO `lms_admin_operation_log` VALUES (441, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 07:58:22', '2020-07-31 07:58:22');
INSERT INTO `lms_admin_operation_log` VALUES (442, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-07-31 07:58:22', '2020-07-31 07:58:22');
INSERT INTO `lms_admin_operation_log` VALUES (443, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 07:59:28', '2020-07-31 07:59:28');
INSERT INTO `lms_admin_operation_log` VALUES (444, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u8033\\u673a\"}', '2020-07-31 07:59:28', '2020-07-31 07:59:28');
INSERT INTO `lms_admin_operation_log` VALUES (445, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 07:59:33', '2020-07-31 07:59:33');
INSERT INTO `lms_admin_operation_log` VALUES (446, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 07:59:34', '2020-07-31 07:59:34');
INSERT INTO `lms_admin_operation_log` VALUES (447, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 07:59:35', '2020-07-31 07:59:35');
INSERT INTO `lms_admin_operation_log` VALUES (448, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u84dd\\u7259\"}', '2020-07-31 07:59:35', '2020-07-31 07:59:35');
INSERT INTO `lms_admin_operation_log` VALUES (449, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u84dd\\u7259\\u8033\\u673a\"}', '2020-07-31 07:59:38', '2020-07-31 07:59:38');
INSERT INTO `lms_admin_operation_log` VALUES (450, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u84dd\"}', '2020-07-31 07:59:40', '2020-07-31 07:59:40');
INSERT INTO `lms_admin_operation_log` VALUES (451, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 07:59:43', '2020-07-31 07:59:43');
INSERT INTO `lms_admin_operation_log` VALUES (452, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 07:59:44', '2020-07-31 07:59:44');
INSERT INTO `lms_admin_operation_log` VALUES (453, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 07:59:44', '2020-07-31 07:59:44');
INSERT INTO `lms_admin_operation_log` VALUES (454, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 07:59:45', '2020-07-31 07:59:45');
INSERT INTO `lms_admin_operation_log` VALUES (455, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u6709\\u7ebf\"}', '2020-07-31 07:59:48', '2020-07-31 07:59:48');
INSERT INTO `lms_admin_operation_log` VALUES (456, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u6709\\u7ebf\\u8033\\u673a\"}', '2020-07-31 07:59:51', '2020-07-31 07:59:51');
INSERT INTO `lms_admin_operation_log` VALUES (457, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"joker\",\"bar_code\":\"1\",\"category_id\":\"7\",\"status\":\"1\",\"shop_id\":\"2\",\"description\":{\"description\":null},\"skus\":{\"new_1\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"description.description\":\"\\u5f88\\u725b\\u903c\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"UmeAeojv9EwRYEmZjKbfQUUuTTYYZS65mBhdvWBL\"}', '2020-07-31 08:00:36', '2020-07-31 08:00:36');
INSERT INTO `lms_admin_operation_log` VALUES (458, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:00:37', '2020-07-31 08:00:37');
INSERT INTO `lms_admin_operation_log` VALUES (459, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"joker\",\"bar_code\":\"1\",\"category_id\":null,\"status\":\"1\",\"shop_id\":\"2\",\"description\":{\"description\":null},\"skus\":{\"new___LA_KEY__\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"description.description\":\"\\u5f88\\u725b\\u903c\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"UmeAeojv9EwRYEmZjKbfQUUuTTYYZS65mBhdvWBL\"}', '2020-07-31 08:00:43', '2020-07-31 08:00:43');
INSERT INTO `lms_admin_operation_log` VALUES (460, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:00:44', '2020-07-31 08:00:44');
INSERT INTO `lms_admin_operation_log` VALUES (461, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:01:26', '2020-07-31 08:01:26');
INSERT INTO `lms_admin_operation_log` VALUES (462, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u8033\\u673a\"}', '2020-07-31 08:01:26', '2020-07-31 08:01:26');
INSERT INTO `lms_admin_operation_log` VALUES (463, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"joker\",\"bar_code\":\"1\",\"category_id\":\"7\",\"status\":\"1\",\"shop_id\":\"2\",\"description\":{\"description\":null},\"skus\":{\"new___LA_KEY__\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"description.description\":\"\\u5f88\\u725b\\u903c\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"UmeAeojv9EwRYEmZjKbfQUUuTTYYZS65mBhdvWBL\"}', '2020-07-31 08:01:32', '2020-07-31 08:01:32');
INSERT INTO `lms_admin_operation_log` VALUES (464, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:01:33', '2020-07-31 08:01:33');
INSERT INTO `lms_admin_operation_log` VALUES (465, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:02:27', '2020-07-31 08:02:27');
INSERT INTO `lms_admin_operation_log` VALUES (466, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:02:50', '2020-07-31 08:02:50');
INSERT INTO `lms_admin_operation_log` VALUES (467, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:02:51', '2020-07-31 08:02:51');
INSERT INTO `lms_admin_operation_log` VALUES (468, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-07-31 08:02:51', '2020-07-31 08:02:51');
INSERT INTO `lms_admin_operation_log` VALUES (469, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"\\u5947\\u5076\\u9648\\u53ef\\u4eba\",\"bar_code\":\"11111111111111111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"description\":{\"description\":null},\"skus\":{\"new_1\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"description.description\":\"\\u5f88\\u725b\\u903c\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"UmeAeojv9EwRYEmZjKbfQUUuTTYYZS65mBhdvWBL\"}', '2020-07-31 08:03:18', '2020-07-31 08:03:18');
INSERT INTO `lms_admin_operation_log` VALUES (470, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:03:18', '2020-07-31 08:03:18');
INSERT INTO `lms_admin_operation_log` VALUES (471, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"\\u5947\\u5076\\u9648\\u53ef\\u4eba\",\"bar_code\":\"11111111111111111\",\"category_id\":null,\"status\":\"1\",\"shop_id\":\"2\",\"description\":{\"description\":null},\"skus\":{\"new___LA_KEY__\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"description.description\":\"\\u5f88\\u725b\\u903c\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"UmeAeojv9EwRYEmZjKbfQUUuTTYYZS65mBhdvWBL\"}', '2020-07-31 08:04:19', '2020-07-31 08:04:19');
INSERT INTO `lms_admin_operation_log` VALUES (472, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:04:19', '2020-07-31 08:04:19');
INSERT INTO `lms_admin_operation_log` VALUES (473, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:04:41', '2020-07-31 08:04:41');
INSERT INTO `lms_admin_operation_log` VALUES (474, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u6709\\u7ebf\"}', '2020-07-31 08:04:42', '2020-07-31 08:04:42');
INSERT INTO `lms_admin_operation_log` VALUES (475, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u6709\\u7ebf\"}', '2020-07-31 08:04:42', '2020-07-31 08:04:42');
INSERT INTO `lms_admin_operation_log` VALUES (476, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u6709\\u7ebf\"}', '2020-07-31 08:04:43', '2020-07-31 08:04:43');
INSERT INTO `lms_admin_operation_log` VALUES (477, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u6709\\u7ebf\"}', '2020-07-31 08:04:45', '2020-07-31 08:04:45');
INSERT INTO `lms_admin_operation_log` VALUES (478, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u6709\\u7ebf\\u8033\\u673a\"}', '2020-07-31 08:04:45', '2020-07-31 08:04:45');
INSERT INTO `lms_admin_operation_log` VALUES (479, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u6709\"}', '2020-07-31 08:04:49', '2020-07-31 08:04:49');
INSERT INTO `lms_admin_operation_log` VALUES (480, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:04:49', '2020-07-31 08:04:49');
INSERT INTO `lms_admin_operation_log` VALUES (481, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:04:49', '2020-07-31 08:04:49');
INSERT INTO `lms_admin_operation_log` VALUES (482, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:04:50', '2020-07-31 08:04:50');
INSERT INTO `lms_admin_operation_log` VALUES (483, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u8033\\u673a\"}', '2020-07-31 08:04:51', '2020-07-31 08:04:51');
INSERT INTO `lms_admin_operation_log` VALUES (484, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u8033\\u673a-\"}', '2020-07-31 08:04:53', '2020-07-31 08:04:53');
INSERT INTO `lms_admin_operation_log` VALUES (485, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u8033\\u673a\"}', '2020-07-31 08:04:55', '2020-07-31 08:04:55');
INSERT INTO `lms_admin_operation_log` VALUES (486, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u8033\"}', '2020-07-31 08:04:56', '2020-07-31 08:04:56');
INSERT INTO `lms_admin_operation_log` VALUES (487, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:04:59', '2020-07-31 08:04:59');
INSERT INTO `lms_admin_operation_log` VALUES (488, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u6536\"}', '2020-07-31 08:05:00', '2020-07-31 08:05:00');
INSERT INTO `lms_admin_operation_log` VALUES (489, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:05:01', '2020-07-31 08:05:01');
INSERT INTO `lms_admin_operation_log` VALUES (490, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\"}', '2020-07-31 08:05:02', '2020-07-31 08:05:02');
INSERT INTO `lms_admin_operation_log` VALUES (491, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:05:07', '2020-07-31 08:05:07');
INSERT INTO `lms_admin_operation_log` VALUES (492, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:05:08', '2020-07-31 08:05:08');
INSERT INTO `lms_admin_operation_log` VALUES (493, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-07-31 08:05:08', '2020-07-31 08:05:08');
INSERT INTO `lms_admin_operation_log` VALUES (494, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-07-31 08:05:10', '2020-07-31 08:05:10');
INSERT INTO `lms_admin_operation_log` VALUES (495, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\\u58f3\"}', '2020-07-31 08:05:11', '2020-07-31 08:05:11');
INSERT INTO `lms_admin_operation_log` VALUES (496, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\"}', '2020-07-31 08:05:13', '2020-07-31 08:05:13');
INSERT INTO `lms_admin_operation_log` VALUES (497, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"\\u5947\\u5076\\u9648\\u53ef\\u4eba\",\"bar_code\":\"11111111111111111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"description\":{\"description\":null},\"skus\":{\"new___LA_KEY__\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"description.description\":\"\\u5f88\\u725b\\u903c\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"UmeAeojv9EwRYEmZjKbfQUUuTTYYZS65mBhdvWBL\"}', '2020-07-31 08:05:29', '2020-07-31 08:05:29');
INSERT INTO `lms_admin_operation_log` VALUES (498, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:05:29', '2020-07-31 08:05:29');
INSERT INTO `lms_admin_operation_log` VALUES (499, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:08:37', '2020-07-31 08:08:37');
INSERT INTO `lms_admin_operation_log` VALUES (500, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-07-31 08:08:56', '2020-07-31 08:08:56');
INSERT INTO `lms_admin_operation_log` VALUES (501, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"joker\",\"bar_code\":\"1111111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"descriptions\":{\"description\":null},\"skus\":{\"new_1\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"descriptions.description\":\"111111\",\"price\":\"11\",\"stock\":\"11111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"UmeAeojv9EwRYEmZjKbfQUUuTTYYZS65mBhdvWBL\"}', '2020-07-31 08:09:17', '2020-07-31 08:09:17');
INSERT INTO `lms_admin_operation_log` VALUES (502, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:09:17', '2020-07-31 08:09:17');
INSERT INTO `lms_admin_operation_log` VALUES (503, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:16:05', '2020-07-31 08:16:05');
INSERT INTO `lms_admin_operation_log` VALUES (504, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:16:26', '2020-07-31 08:16:26');
INSERT INTO `lms_admin_operation_log` VALUES (505, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-07-31 08:16:26', '2020-07-31 08:16:26');
INSERT INTO `lms_admin_operation_log` VALUES (506, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"jocker\",\"bar_code\":\"1111111111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"skus\":{\"new_1\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":\"11111\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"UmeAeojv9EwRYEmZjKbfQUUuTTYYZS65mBhdvWBL\"}', '2020-07-31 08:16:41', '2020-07-31 08:16:41');
INSERT INTO `lms_admin_operation_log` VALUES (507, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:16:42', '2020-07-31 08:16:42');
INSERT INTO `lms_admin_operation_log` VALUES (508, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:17:01', '2020-07-31 08:17:01');
INSERT INTO `lms_admin_operation_log` VALUES (509, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-07-31 08:17:02', '2020-07-31 08:17:02');
INSERT INTO `lms_admin_operation_log` VALUES (510, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"jocker\",\"bar_code\":\"1111111111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"skus\":{\"new___LA_KEY__\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":\"11111\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"UmeAeojv9EwRYEmZjKbfQUUuTTYYZS65mBhdvWBL\"}', '2020-07-31 08:17:06', '2020-07-31 08:17:06');
INSERT INTO `lms_admin_operation_log` VALUES (511, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:17:06', '2020-07-31 08:17:06');
INSERT INTO `lms_admin_operation_log` VALUES (512, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:51:14', '2020-07-31 08:51:14');
INSERT INTO `lms_admin_operation_log` VALUES (513, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"shouji\"}', '2020-07-31 08:54:47', '2020-07-31 08:54:47');
INSERT INTO `lms_admin_operation_log` VALUES (514, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"shouj\"}', '2020-07-31 08:54:48', '2020-07-31 08:54:48');
INSERT INTO `lms_admin_operation_log` VALUES (515, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"s\"}', '2020-07-31 08:54:48', '2020-07-31 08:54:48');
INSERT INTO `lms_admin_operation_log` VALUES (516, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:54:49', '2020-07-31 08:54:49');
INSERT INTO `lms_admin_operation_log` VALUES (517, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:54:49', '2020-07-31 08:54:49');
INSERT INTO `lms_admin_operation_log` VALUES (518, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-07-31 08:54:50', '2020-07-31 08:54:50');
INSERT INTO `lms_admin_operation_log` VALUES (519, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"joker\",\"bar_code\":\"11111111111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"skus\":{\"new_1\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":\"11111\",\"price\":null,\"stock\":null,\"id\":null,\"_remove_\":\"1\"}},\"_token\":\"UmeAeojv9EwRYEmZjKbfQUUuTTYYZS65mBhdvWBL\"}', '2020-07-31 08:55:02', '2020-07-31 08:55:02');
INSERT INTO `lms_admin_operation_log` VALUES (520, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:55:03', '2020-07-31 08:55:03');
INSERT INTO `lms_admin_operation_log` VALUES (521, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"joker\",\"bar_code\":\"11111111111\",\"category_id\":null,\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"_token\":\"UmeAeojv9EwRYEmZjKbfQUUuTTYYZS65mBhdvWBL\"}', '2020-07-31 08:55:37', '2020-07-31 08:55:37');
INSERT INTO `lms_admin_operation_log` VALUES (522, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:55:38', '2020-07-31 08:55:38');
INSERT INTO `lms_admin_operation_log` VALUES (523, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:55:46', '2020-07-31 08:55:46');
INSERT INTO `lms_admin_operation_log` VALUES (524, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u8033\\u673a\"}', '2020-07-31 08:55:47', '2020-07-31 08:55:47');
INSERT INTO `lms_admin_operation_log` VALUES (525, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"joker\",\"bar_code\":\"11111111111\",\"category_id\":\"7\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"_token\":\"UmeAeojv9EwRYEmZjKbfQUUuTTYYZS65mBhdvWBL\"}', '2020-07-31 08:56:00', '2020-07-31 08:56:00');
INSERT INTO `lms_admin_operation_log` VALUES (526, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:56:00', '2020-07-31 08:56:00');
INSERT INTO `lms_admin_operation_log` VALUES (527, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 08:57:18', '2020-07-31 08:57:18');
INSERT INTO `lms_admin_operation_log` VALUES (528, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 08:57:32', '2020-07-31 08:57:32');
INSERT INTO `lms_admin_operation_log` VALUES (529, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u8033\\u673a\"}', '2020-07-31 08:57:33', '2020-07-31 08:57:33');
INSERT INTO `lms_admin_operation_log` VALUES (530, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"\\u5947\\u5076\\u9648\\u53ef\\u4eba\",\"bar_code\":\"11111\",\"category_id\":\"7\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"_token\":\"UmeAeojv9EwRYEmZjKbfQUUuTTYYZS65mBhdvWBL\"}', '2020-07-31 08:57:38', '2020-07-31 08:57:38');
INSERT INTO `lms_admin_operation_log` VALUES (531, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-31 08:57:38', '2020-07-31 08:57:38');
INSERT INTO `lms_admin_operation_log` VALUES (532, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-31 08:58:03', '2020-07-31 08:58:03');
INSERT INTO `lms_admin_operation_log` VALUES (533, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-31 08:58:46', '2020-07-31 08:58:46');
INSERT INTO `lms_admin_operation_log` VALUES (534, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 09:03:05', '2020-07-31 09:03:05');
INSERT INTO `lms_admin_operation_log` VALUES (535, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 09:03:28', '2020-07-31 09:03:28');
INSERT INTO `lms_admin_operation_log` VALUES (536, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 09:03:42', '2020-07-31 09:03:42');
INSERT INTO `lms_admin_operation_log` VALUES (537, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-07-31 09:03:43', '2020-07-31 09:03:43');
INSERT INTO `lms_admin_operation_log` VALUES (538, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"admin\",\"bar_code\":\"11111\",\"category_id\":\"7\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"skus\":{\"new_1\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":null,\"price\":null,\"stock\":null,\"id\":null,\"_remove_\":\"1\"}},\"_token\":\"UmeAeojv9EwRYEmZjKbfQUUuTTYYZS65mBhdvWBL\"}', '2020-07-31 09:04:05', '2020-07-31 09:04:05');
INSERT INTO `lms_admin_operation_log` VALUES (539, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 09:04:06', '2020-07-31 09:04:06');
INSERT INTO `lms_admin_operation_log` VALUES (540, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-07-31 09:14:13', '2020-07-31 09:14:13');
INSERT INTO `lms_admin_operation_log` VALUES (541, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-31 09:17:01', '2020-07-31 09:17:01');
INSERT INTO `lms_admin_operation_log` VALUES (542, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-07-31 09:17:06', '2020-07-31 09:17:06');
INSERT INTO `lms_admin_operation_log` VALUES (543, 1, 'admin/products/7/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-31 09:17:11', '2020-07-31 09:17:11');
INSERT INTO `lms_admin_operation_log` VALUES (544, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-31 09:18:42', '2020-07-31 09:18:42');
INSERT INTO `lms_admin_operation_log` VALUES (545, 1, 'admin/products/37/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-31 09:19:08', '2020-07-31 09:19:08');
INSERT INTO `lms_admin_operation_log` VALUES (546, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-31 09:19:19', '2020-07-31 09:19:19');
INSERT INTO `lms_admin_operation_log` VALUES (547, 1, 'admin/products/55/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-07-31 09:19:26', '2020-07-31 09:19:26');
INSERT INTO `lms_admin_operation_log` VALUES (548, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-08-01 05:18:36', '2020-08-01 05:18:36');
INSERT INTO `lms_admin_operation_log` VALUES (549, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 05:18:41', '2020-08-01 05:18:41');
INSERT INTO `lms_admin_operation_log` VALUES (550, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-08-01 05:18:42', '2020-08-01 05:18:42');
INSERT INTO `lms_admin_operation_log` VALUES (551, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-08-01 05:18:56', '2020-08-01 05:18:56');
INSERT INTO `lms_admin_operation_log` VALUES (552, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 05:18:58', '2020-08-01 05:18:58');
INSERT INTO `lms_admin_operation_log` VALUES (553, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-08-01 05:18:59', '2020-08-01 05:18:59');
INSERT INTO `lms_admin_operation_log` VALUES (554, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-08-01 05:38:08', '2020-08-01 05:38:08');
INSERT INTO `lms_admin_operation_log` VALUES (555, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 05:38:10', '2020-08-01 05:38:10');
INSERT INTO `lms_admin_operation_log` VALUES (556, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:38:50', '2020-08-01 05:38:50');
INSERT INTO `lms_admin_operation_log` VALUES (557, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:38:50', '2020-08-01 05:38:50');
INSERT INTO `lms_admin_operation_log` VALUES (558, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u8033\\u673a\"}', '2020-08-01 05:38:51', '2020-08-01 05:38:51');
INSERT INTO `lms_admin_operation_log` VALUES (559, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"joker\",\"bar_code\":\"11111\",\"category_id\":\"7\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"skus\":{\"new_1\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":\"11111\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/products\"}', '2020-08-01 05:39:04', '2020-08-01 05:39:04');
INSERT INTO `lms_admin_operation_log` VALUES (560, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 05:39:06', '2020-08-01 05:39:06');
INSERT INTO `lms_admin_operation_log` VALUES (561, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"joker\",\"bar_code\":\"11111\",\"category_id\":null,\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"skus\":{\"new___LA_KEY__\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":\"11111\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\"}', '2020-08-01 05:41:21', '2020-08-01 05:41:21');
INSERT INTO `lms_admin_operation_log` VALUES (562, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 05:41:21', '2020-08-01 05:41:21');
INSERT INTO `lms_admin_operation_log` VALUES (563, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:41:31', '2020-08-01 05:41:31');
INSERT INTO `lms_admin_operation_log` VALUES (564, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:41:31', '2020-08-01 05:41:31');
INSERT INTO `lms_admin_operation_log` VALUES (565, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:41:32', '2020-08-01 05:41:32');
INSERT INTO `lms_admin_operation_log` VALUES (566, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:41:33', '2020-08-01 05:41:33');
INSERT INTO `lms_admin_operation_log` VALUES (567, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:41:33', '2020-08-01 05:41:33');
INSERT INTO `lms_admin_operation_log` VALUES (568, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:41:33', '2020-08-01 05:41:33');
INSERT INTO `lms_admin_operation_log` VALUES (569, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:41:33', '2020-08-01 05:41:33');
INSERT INTO `lms_admin_operation_log` VALUES (570, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:41:34', '2020-08-01 05:41:34');
INSERT INTO `lms_admin_operation_log` VALUES (571, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 05:41:34', '2020-08-01 05:41:34');
INSERT INTO `lms_admin_operation_log` VALUES (572, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"joker\",\"bar_code\":\"11111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"skus\":{\"new___LA_KEY__\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":\"11111\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\"}', '2020-08-01 05:41:41', '2020-08-01 05:41:41');
INSERT INTO `lms_admin_operation_log` VALUES (573, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 05:41:42', '2020-08-01 05:41:42');
INSERT INTO `lms_admin_operation_log` VALUES (574, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:49:28', '2020-08-01 05:49:28');
INSERT INTO `lms_admin_operation_log` VALUES (575, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:49:28', '2020-08-01 05:49:28');
INSERT INTO `lms_admin_operation_log` VALUES (576, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 05:49:29', '2020-08-01 05:49:29');
INSERT INTO `lms_admin_operation_log` VALUES (577, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"joker\",\"bar_code\":\"11111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"skus\":{\"new___LA_KEY__\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":\"11111\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\"}', '2020-08-01 05:50:10', '2020-08-01 05:50:10');
INSERT INTO `lms_admin_operation_log` VALUES (578, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 05:50:11', '2020-08-01 05:50:11');
INSERT INTO `lms_admin_operation_log` VALUES (579, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"joker\",\"bar_code\":\"11111\",\"category_id\":null,\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"skus\":{\"new___LA_KEY__\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":\"11111\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\"}', '2020-08-01 05:51:44', '2020-08-01 05:51:44');
INSERT INTO `lms_admin_operation_log` VALUES (580, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 05:51:44', '2020-08-01 05:51:44');
INSERT INTO `lms_admin_operation_log` VALUES (581, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:51:52', '2020-08-01 05:51:52');
INSERT INTO `lms_admin_operation_log` VALUES (582, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:51:53', '2020-08-01 05:51:53');
INSERT INTO `lms_admin_operation_log` VALUES (583, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 05:51:53', '2020-08-01 05:51:53');
INSERT INTO `lms_admin_operation_log` VALUES (584, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"joker\",\"bar_code\":\"11111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"skus\":{\"new___LA_KEY__\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":\"11111\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\"}', '2020-08-01 05:51:58', '2020-08-01 05:51:58');
INSERT INTO `lms_admin_operation_log` VALUES (585, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 05:51:59', '2020-08-01 05:51:59');
INSERT INTO `lms_admin_operation_log` VALUES (586, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 05:53:01', '2020-08-01 05:53:01');
INSERT INTO `lms_admin_operation_log` VALUES (587, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:53:21', '2020-08-01 05:53:21');
INSERT INTO `lms_admin_operation_log` VALUES (588, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:53:21', '2020-08-01 05:53:21');
INSERT INTO `lms_admin_operation_log` VALUES (589, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 05:53:22', '2020-08-01 05:53:22');
INSERT INTO `lms_admin_operation_log` VALUES (590, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"jocker\",\"bar_code\":\"11111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"skus\":{\"new_1\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":\"11111\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/products\"}', '2020-08-01 05:53:34', '2020-08-01 05:53:34');
INSERT INTO `lms_admin_operation_log` VALUES (591, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 05:53:35', '2020-08-01 05:53:35');
INSERT INTO `lms_admin_operation_log` VALUES (592, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:53:51', '2020-08-01 05:53:51');
INSERT INTO `lms_admin_operation_log` VALUES (593, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:53:51', '2020-08-01 05:53:51');
INSERT INTO `lms_admin_operation_log` VALUES (594, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:53:52', '2020-08-01 05:53:52');
INSERT INTO `lms_admin_operation_log` VALUES (595, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:53:53', '2020-08-01 05:53:53');
INSERT INTO `lms_admin_operation_log` VALUES (596, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:53:54', '2020-08-01 05:53:54');
INSERT INTO `lms_admin_operation_log` VALUES (597, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:53:55', '2020-08-01 05:53:55');
INSERT INTO `lms_admin_operation_log` VALUES (598, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 05:53:56', '2020-08-01 05:53:56');
INSERT INTO `lms_admin_operation_log` VALUES (599, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 05:53:56', '2020-08-01 05:53:56');
INSERT INTO `lms_admin_operation_log` VALUES (600, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"jocker\",\"bar_code\":\"11111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"skus\":{\"new___LA_KEY__\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":\"11111\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"1\"}},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\"}', '2020-08-01 05:54:00', '2020-08-01 05:54:00');
INSERT INTO `lms_admin_operation_log` VALUES (601, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-08-01 05:54:01', '2020-08-01 05:54:01');
INSERT INTO `lms_admin_operation_log` VALUES (602, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 06:12:41', '2020-08-01 06:12:41');
INSERT INTO `lms_admin_operation_log` VALUES (603, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 06:12:55', '2020-08-01 06:12:55');
INSERT INTO `lms_admin_operation_log` VALUES (604, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 06:12:55', '2020-08-01 06:12:55');
INSERT INTO `lms_admin_operation_log` VALUES (605, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 06:12:56', '2020-08-01 06:12:56');
INSERT INTO `lms_admin_operation_log` VALUES (606, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 06:12:57', '2020-08-01 06:12:57');
INSERT INTO `lms_admin_operation_log` VALUES (607, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"\\u8f66\\u524d\\u8349\",\"bar_code\":\"11111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"skus\":{\"new_1\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":\"11111\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/products\"}', '2020-08-01 06:13:07', '2020-08-01 06:13:07');
INSERT INTO `lms_admin_operation_log` VALUES (608, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 06:13:08', '2020-08-01 06:13:08');
INSERT INTO `lms_admin_operation_log` VALUES (609, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 06:18:41', '2020-08-01 06:18:41');
INSERT INTO `lms_admin_operation_log` VALUES (610, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 06:18:53', '2020-08-01 06:18:53');
INSERT INTO `lms_admin_operation_log` VALUES (611, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 06:18:53', '2020-08-01 06:18:53');
INSERT INTO `lms_admin_operation_log` VALUES (612, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 06:18:54', '2020-08-01 06:18:54');
INSERT INTO `lms_admin_operation_log` VALUES (613, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 06:18:54', '2020-08-01 06:18:54');
INSERT INTO `lms_admin_operation_log` VALUES (614, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"\\u5b8c\\u6210\\u5168\\u989d\",\"bar_code\":\"11111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":null},\"skus\":{\"new_1\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"description\":\"111111\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\"}', '2020-08-01 06:19:08', '2020-08-01 06:19:08');
INSERT INTO `lms_admin_operation_log` VALUES (615, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-08-01 06:19:09', '2020-08-01 06:19:09');
INSERT INTO `lms_admin_operation_log` VALUES (616, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-08-01 06:21:37', '2020-08-01 06:21:37');
INSERT INTO `lms_admin_operation_log` VALUES (617, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 06:21:40', '2020-08-01 06:21:40');
INSERT INTO `lms_admin_operation_log` VALUES (618, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 07:26:28', '2020-08-01 07:26:28');
INSERT INTO `lms_admin_operation_log` VALUES (619, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 07:26:52', '2020-08-01 07:26:52');
INSERT INTO `lms_admin_operation_log` VALUES (620, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 07:26:52', '2020-08-01 07:26:52');
INSERT INTO `lms_admin_operation_log` VALUES (621, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 07:26:52', '2020-08-01 07:26:52');
INSERT INTO `lms_admin_operation_log` VALUES (622, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 07:26:53', '2020-08-01 07:26:53');
INSERT INTO `lms_admin_operation_log` VALUES (623, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"\\u7ea7\\u7684\\u4eba\",\"bar_code\":\"11111\",\"category_id\":\"1\",\"status\":\"0\",\"shop_id\":\"2\",\"description\":\"<p>11111111111111111111<\\/p>\",\"skus\":{\"new_1\":{\"title\":\"1111111111111111\",\"description\":\"111111\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/products\"}', '2020-08-01 07:27:04', '2020-08-01 07:27:04');
INSERT INTO `lms_admin_operation_log` VALUES (624, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 07:27:06', '2020-08-01 07:27:06');
INSERT INTO `lms_admin_operation_log` VALUES (625, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 07:34:00', '2020-08-01 07:34:00');
INSERT INTO `lms_admin_operation_log` VALUES (626, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"shou\"}', '2020-08-01 07:35:40', '2020-08-01 07:35:40');
INSERT INTO `lms_admin_operation_log` VALUES (627, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"shouji\"}', '2020-08-01 07:35:40', '2020-08-01 07:35:40');
INSERT INTO `lms_admin_operation_log` VALUES (628, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 07:35:45', '2020-08-01 07:35:45');
INSERT INTO `lms_admin_operation_log` VALUES (629, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"wdwcwdc\",\"bar_code\":\"11111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":\"1111111111111111111111111111111111111\"},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\"}', '2020-08-01 07:35:51', '2020-08-01 07:35:51');
INSERT INTO `lms_admin_operation_log` VALUES (630, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-08-01 07:35:51', '2020-08-01 07:35:51');
INSERT INTO `lms_admin_operation_log` VALUES (631, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-08-01 07:47:24', '2020-08-01 07:47:24');
INSERT INTO `lms_admin_operation_log` VALUES (632, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 07:47:27', '2020-08-01 07:47:27');
INSERT INTO `lms_admin_operation_log` VALUES (633, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 07:48:06', '2020-08-01 07:48:06');
INSERT INTO `lms_admin_operation_log` VALUES (634, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 07:48:06', '2020-08-01 07:48:06');
INSERT INTO `lms_admin_operation_log` VALUES (635, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"joker\",\"bar_code\":\"11111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":\"<p><\\/p><p>1111111111111111111<\\/p>\"},\"skus\":{\"new_1\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"description\":\"111111\",\"price\":\"1\",\"stock\":\"11111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/products\"}', '2020-08-01 07:48:18', '2020-08-01 07:48:18');
INSERT INTO `lms_admin_operation_log` VALUES (636, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-08-01 07:48:19', '2020-08-01 07:48:19');
INSERT INTO `lms_admin_operation_log` VALUES (637, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 07:51:13', '2020-08-01 07:51:13');
INSERT INTO `lms_admin_operation_log` VALUES (638, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 07:51:29', '2020-08-01 07:51:29');
INSERT INTO `lms_admin_operation_log` VALUES (639, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 07:51:30', '2020-08-01 07:51:30');
INSERT INTO `lms_admin_operation_log` VALUES (640, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 07:51:30', '2020-08-01 07:51:30');
INSERT INTO `lms_admin_operation_log` VALUES (641, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"joker\",\"bar_code\":\"11111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":\"<p><\\/p><p>111111111111<\\/p>\"},\"skus\":{\"new_1\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":\"11111\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/products\"}', '2020-08-01 07:51:42', '2020-08-01 07:51:42');
INSERT INTO `lms_admin_operation_log` VALUES (642, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 07:51:43', '2020-08-01 07:51:43');
INSERT INTO `lms_admin_operation_log` VALUES (643, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 07:52:46', '2020-08-01 07:52:46');
INSERT INTO `lms_admin_operation_log` VALUES (644, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 07:52:47', '2020-08-01 07:52:47');
INSERT INTO `lms_admin_operation_log` VALUES (645, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 07:52:47', '2020-08-01 07:52:47');
INSERT INTO `lms_admin_operation_log` VALUES (646, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 07:52:48', '2020-08-01 07:52:48');
INSERT INTO `lms_admin_operation_log` VALUES (647, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 07:52:48', '2020-08-01 07:52:48');
INSERT INTO `lms_admin_operation_log` VALUES (648, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 07:52:49', '2020-08-01 07:52:49');
INSERT INTO `lms_admin_operation_log` VALUES (649, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 07:52:49', '2020-08-01 07:52:49');
INSERT INTO `lms_admin_operation_log` VALUES (650, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 07:52:50', '2020-08-01 07:52:50');
INSERT INTO `lms_admin_operation_log` VALUES (651, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 07:52:50', '2020-08-01 07:52:50');
INSERT INTO `lms_admin_operation_log` VALUES (652, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"joker\",\"bar_code\":\"11111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":\"<p><\\/p><p>111111111111<\\/p>\"},\"skus\":{\"new___LA_KEY__\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":\"11111\",\"price\":\"1\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\"}', '2020-08-01 07:52:55', '2020-08-01 07:52:55');
INSERT INTO `lms_admin_operation_log` VALUES (653, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 07:52:56', '2020-08-01 07:52:56');
INSERT INTO `lms_admin_operation_log` VALUES (654, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 07:53:51', '2020-08-01 07:53:51');
INSERT INTO `lms_admin_operation_log` VALUES (655, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 07:54:09', '2020-08-01 07:54:09');
INSERT INTO `lms_admin_operation_log` VALUES (656, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 07:54:09', '2020-08-01 07:54:09');
INSERT INTO `lms_admin_operation_log` VALUES (657, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 07:54:10', '2020-08-01 07:54:10');
INSERT INTO `lms_admin_operation_log` VALUES (658, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"jokers\",\"bar_code\":\"11111\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":\"<p><\\/p><p>11111111111111<\\/p>\"},\"skus\":{\"new_1\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":\"<p><\\/p><p>111111111111111<\\/p>\",\"price\":\"11\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/products\"}', '2020-08-01 07:54:21', '2020-08-01 07:54:21');
INSERT INTO `lms_admin_operation_log` VALUES (659, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 07:54:22', '2020-08-01 07:54:22');
INSERT INTO `lms_admin_operation_log` VALUES (660, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 07:54:33', '2020-08-01 07:54:33');
INSERT INTO `lms_admin_operation_log` VALUES (661, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"jokers\",\"bar_code\":\"11111\",\"category_id\":\"24\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":\"<p><\\/p><p>11111111111111<\\/p>\"},\"skus\":{\"new___LA_KEY__\":{\"title\":\"\\u9ed1\\u8272joker 1\\u7c7370\",\"productskudescriptions.description\":\"<p><\\/p><p>111111111111111<\\/p>\",\"price\":\"11\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"s1EKCTijwsEbInPcpo5MUlREzNh1kZvn4fBs8yk9\"}', '2020-08-01 07:54:38', '2020-08-01 07:54:38');
INSERT INTO `lms_admin_operation_log` VALUES (662, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 07:54:38', '2020-08-01 07:54:38');
INSERT INTO `lms_admin_operation_log` VALUES (663, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 08:02:15', '2020-08-01 08:02:15');
INSERT INTO `lms_admin_operation_log` VALUES (664, 1, 'admin/auth/permissions/6', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 08:02:18', '2020-08-01 08:02:18');
INSERT INTO `lms_admin_operation_log` VALUES (665, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 08:02:22', '2020-08-01 08:02:22');
INSERT INTO `lms_admin_operation_log` VALUES (666, 1, 'admin/auth/permissions/6/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 08:02:25', '2020-08-01 08:02:25');
INSERT INTO `lms_admin_operation_log` VALUES (667, 1, 'admin/categories', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 08:05:35', '2020-08-01 08:05:35');
INSERT INTO `lms_admin_operation_log` VALUES (668, 1, 'admin/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 08:05:39', '2020-08-01 08:05:39');
INSERT INTO `lms_admin_operation_log` VALUES (669, 1, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 08:05:44', '2020-08-01 08:05:44');
INSERT INTO `lms_admin_operation_log` VALUES (670, 1, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 08:35:22', '2020-08-01 08:35:22');
INSERT INTO `lms_admin_operation_log` VALUES (671, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 08:35:23', '2020-08-01 08:35:23');
INSERT INTO `lms_admin_operation_log` VALUES (672, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-08-01 11:07:40', '2020-08-01 11:07:40');
INSERT INTO `lms_admin_operation_log` VALUES (673, 1, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 11:07:45', '2020-08-01 11:07:45');
INSERT INTO `lms_admin_operation_log` VALUES (674, 1, 'admin/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 11:08:12', '2020-08-01 11:08:12');
INSERT INTO `lms_admin_operation_log` VALUES (675, 1, 'admin/categories', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 11:08:39', '2020-08-01 11:08:39');
INSERT INTO `lms_admin_operation_log` VALUES (676, 1, 'admin', 'GET', '127.0.0.1', '[]', '2020-08-01 14:07:29', '2020-08-01 14:07:29');
INSERT INTO `lms_admin_operation_log` VALUES (677, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 14:07:34', '2020-08-01 14:07:34');
INSERT INTO `lms_admin_operation_log` VALUES (678, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 14:07:37', '2020-08-01 14:07:37');
INSERT INTO `lms_admin_operation_log` VALUES (679, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 14:08:28', '2020-08-01 14:08:28');
INSERT INTO `lms_admin_operation_log` VALUES (680, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"\\u534e\\u4e3a\\u624b\\u673a\",\"bar_code\":\"1111111111111111\",\"category_id\":\"24\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":\"<p><\\/p><p>111111111111111111<\\/p>\"},\"_token\":\"c5uXZXftLNRZyzHYMesh4IJfpYKrl8hOaT6DEJDE\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/products\"}', '2020-08-01 14:08:35', '2020-08-01 14:08:35');
INSERT INTO `lms_admin_operation_log` VALUES (681, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-08-01 14:08:35', '2020-08-01 14:08:35');
INSERT INTO `lms_admin_operation_log` VALUES (682, 1, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"2\",\"_pjax\":\"#pjax-container\"}', '2020-08-01 14:08:40', '2020-08-01 14:08:40');
INSERT INTO `lms_admin_operation_log` VALUES (683, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\",\"page\":\"1\"}', '2020-08-01 14:09:51', '2020-08-01 14:09:51');
INSERT INTO `lms_admin_operation_log` VALUES (684, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 14:10:42', '2020-08-01 14:10:42');
INSERT INTO `lms_admin_operation_log` VALUES (685, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 14:14:37', '2020-08-01 14:14:37');
INSERT INTO `lms_admin_operation_log` VALUES (686, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"\\u534e\\u4e3a\\u7535\\u8111\",\"bar_code\":\"22222222222\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":null,\"productdescriptions\":{\"description\":\"<p><\\/p><p>\\u534e\\u4e3a\\u7535\\u8111<\\/p>\"},\"skus\":{\"new_1\":{\"title\":\"\\u534e\\u4e3a16\",\"productskudescriptions.description\":null,\"price\":null,\"stock\":null,\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"c5uXZXftLNRZyzHYMesh4IJfpYKrl8hOaT6DEJDE\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/products?&page=1\"}', '2020-08-01 14:15:09', '2020-08-01 14:15:09');
INSERT INTO `lms_admin_operation_log` VALUES (687, 1, 'admin/products/create', 'GET', '127.0.0.1', '[]', '2020-08-01 14:15:09', '2020-08-01 14:15:09');
INSERT INTO `lms_admin_operation_log` VALUES (688, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 14:15:24', '2020-08-01 14:15:24');
INSERT INTO `lms_admin_operation_log` VALUES (689, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 14:15:25', '2020-08-01 14:15:25');
INSERT INTO `lms_admin_operation_log` VALUES (690, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"\\u534e\\u4e3a\\u7535\\u8111\",\"bar_code\":\"22222222222\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":\"<p><\\/p><p>\\u534e\\u4e3a\\u7535\\u8111<\\/p>\"},\"skus\":{\"new___LA_KEY__\":{\"title\":\"\\u534e\\u4e3a\\u8fd0\\u884c\\u5185\\u5b5816G  \\u7269\\u7406\\u5185\\u5b581T\",\"description\":\"16G\",\"price\":\"111111\",\"stock\":\"111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"c5uXZXftLNRZyzHYMesh4IJfpYKrl8hOaT6DEJDE\"}', '2020-08-01 14:16:01', '2020-08-01 14:16:01');
INSERT INTO `lms_admin_operation_log` VALUES (691, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-08-01 14:16:01', '2020-08-01 14:16:01');
INSERT INTO `lms_admin_operation_log` VALUES (692, 1, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"2\",\"_pjax\":\"#pjax-container\"}', '2020-08-01 14:16:05', '2020-08-01 14:16:05');
INSERT INTO `lms_admin_operation_log` VALUES (693, 1, 'admin/products/73/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 14:16:17', '2020-08-01 14:16:17');
INSERT INTO `lms_admin_operation_log` VALUES (694, 1, 'admin/products/73', 'PUT', '127.0.0.1', '{\"title\":\"\\u534e\\u4e3a\\u7535\\u8111\",\"bar_code\":\"22222222222\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":\"<p><\\/p><p>\\u534e\\u4e3a\\u7535\\u8111<\\/p>\"},\"skus\":{\"96\":{\"title\":\"\\u534e\\u4e3a\\u8fd0\\u884c\\u5185\\u5b5816G  \\u7269\\u7406\\u5185\\u5b581T\",\"description\":\"16G\",\"price\":\"111111.00\",\"stock\":\"111\",\"id\":\"96\",\"_remove_\":\"0\"},\"new_1\":{\"title\":\"\\u534e\\u4e3a\\u8fd0\\u884c\\u5185\\u5b5816G  \\u7269\\u7406\\u5185\\u5b58520MB\",\"description\":\"2222\",\"price\":\"11\",\"stock\":\"1111\",\"id\":null,\"_remove_\":\"0\"}},\"_token\":\"c5uXZXftLNRZyzHYMesh4IJfpYKrl8hOaT6DEJDE\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/products?page=2\"}', '2020-08-01 14:16:49', '2020-08-01 14:16:49');
INSERT INTO `lms_admin_operation_log` VALUES (695, 1, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"2\"}', '2020-08-01 14:16:49', '2020-08-01 14:16:49');
INSERT INTO `lms_admin_operation_log` VALUES (696, 1, 'admin/products/73/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 14:17:47', '2020-08-01 14:17:47');
INSERT INTO `lms_admin_operation_log` VALUES (697, 1, 'admin/products/73', 'PUT', '127.0.0.1', '{\"title\":\"\\u534e\\u4e3a\\u7535\\u8111\",\"bar_code\":\"22222222222\",\"category_id\":\"1\",\"status\":\"1\",\"shop_id\":\"2\",\"productdescriptions\":{\"description\":\"<p><\\/p><p>\\u534e\\u4e3a\\u7535\\u8111<\\/p>\"},\"skus\":{\"96\":{\"title\":\"\\u534e\\u4e3a\\u8fd0\\u884c\\u5185\\u5b5816G  \\u7269\\u7406\\u5185\\u5b581T\",\"description\":\"16G\",\"price\":\"10\",\"stock\":\"111\",\"id\":\"96\",\"_remove_\":\"0\"},\"97\":{\"title\":\"\\u534e\\u4e3a\\u8fd0\\u884c\\u5185\\u5b5816G  \\u7269\\u7406\\u5185\\u5b58520MB\",\"description\":\"2222\",\"price\":\"12222\",\"stock\":\"1111\",\"id\":\"97\",\"_remove_\":\"0\"}},\"_token\":\"c5uXZXftLNRZyzHYMesh4IJfpYKrl8hOaT6DEJDE\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/products?page=2\"}', '2020-08-01 14:18:00', '2020-08-01 14:18:00');
INSERT INTO `lms_admin_operation_log` VALUES (698, 1, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"2\"}', '2020-08-01 14:18:01', '2020-08-01 14:18:01');
INSERT INTO `lms_admin_operation_log` VALUES (699, 1, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 14:18:14', '2020-08-01 14:18:14');
INSERT INTO `lms_admin_operation_log` VALUES (700, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 14:18:17', '2020-08-01 14:18:17');
INSERT INTO `lms_admin_operation_log` VALUES (701, 1, 'admin/shops', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 14:18:19', '2020-08-01 14:18:19');
INSERT INTO `lms_admin_operation_log` VALUES (702, 1, 'admin/shops/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 14:18:21', '2020-08-01 14:18:21');
INSERT INTO `lms_admin_operation_log` VALUES (703, 1, 'admin/shops', 'POST', '127.0.0.1', '{\"name\":\"leo\",\"_token\":\"c5uXZXftLNRZyzHYMesh4IJfpYKrl8hOaT6DEJDE\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/shops\"}', '2020-08-01 14:18:24', '2020-08-01 14:18:24');
INSERT INTO `lms_admin_operation_log` VALUES (704, 1, 'admin/shops', 'GET', '127.0.0.1', '[]', '2020-08-01 14:18:25', '2020-08-01 14:18:25');
INSERT INTO `lms_admin_operation_log` VALUES (705, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 14:18:29', '2020-08-01 14:18:29');
INSERT INTO `lms_admin_operation_log` VALUES (706, 1, 'admin/products/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 14:18:31', '2020-08-01 14:18:31');
INSERT INTO `lms_admin_operation_log` VALUES (707, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"s\"}', '2020-08-01 14:18:45', '2020-08-01 14:18:45');
INSERT INTO `lms_admin_operation_log` VALUES (708, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"shou\"}', '2020-08-01 14:18:45', '2020-08-01 14:18:45');
INSERT INTO `lms_admin_operation_log` VALUES (709, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"shouji\"}', '2020-08-01 14:18:46', '2020-08-01 14:18:46');
INSERT INTO `lms_admin_operation_log` VALUES (710, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"s\"}', '2020-08-01 14:18:47', '2020-08-01 14:18:47');
INSERT INTO `lms_admin_operation_log` VALUES (711, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 14:18:48', '2020-08-01 14:18:48');
INSERT INTO `lms_admin_operation_log` VALUES (712, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":null}', '2020-08-01 14:18:49', '2020-08-01 14:18:49');
INSERT INTO `lms_admin_operation_log` VALUES (713, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u4e00\\u4f53\\u673a\"}', '2020-08-01 14:18:50', '2020-08-01 14:18:50');
INSERT INTO `lms_admin_operation_log` VALUES (714, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u4e00\\u4f53\"}', '2020-08-01 14:18:51', '2020-08-01 14:18:51');
INSERT INTO `lms_admin_operation_log` VALUES (715, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u4e00\"}', '2020-08-01 14:18:52', '2020-08-01 14:18:52');
INSERT INTO `lms_admin_operation_log` VALUES (716, 1, 'admin/api/categories', 'GET', '127.0.0.1', '{\"is_directory\":\"0\",\"q\":\"\\u624b\\u673a\"}', '2020-08-01 14:18:54', '2020-08-01 14:18:54');
INSERT INTO `lms_admin_operation_log` VALUES (717, 1, 'admin/products', 'POST', '127.0.0.1', '{\"title\":\"will\",\"bar_code\":\"111111111111\",\"category_id\":\"24\",\"status\":\"1\",\"shop_id\":\"5\",\"productdescriptions\":{\"description\":\"<p><\\/p><p>11111111111<\\/p>\"},\"_token\":\"c5uXZXftLNRZyzHYMesh4IJfpYKrl8hOaT6DEJDE\",\"_previous_\":\"http:\\/\\/blog-shop.com\\/admin\\/products\"}', '2020-08-01 14:19:02', '2020-08-01 14:19:02');
INSERT INTO `lms_admin_operation_log` VALUES (718, 1, 'admin/products', 'GET', '127.0.0.1', '[]', '2020-08-01 14:19:02', '2020-08-01 14:19:02');
INSERT INTO `lms_admin_operation_log` VALUES (719, 1, 'admin/products', 'GET', '127.0.0.1', '{\"page\":\"2\",\"_pjax\":\"#pjax-container\"}', '2020-08-01 14:19:07', '2020-08-01 14:19:07');
INSERT INTO `lms_admin_operation_log` VALUES (720, 1, 'admin/products/63/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 14:20:20', '2020-08-01 14:20:20');
INSERT INTO `lms_admin_operation_log` VALUES (721, 1, 'admin/products/63/edit', 'GET', '127.0.0.1', '[]', '2020-08-01 14:22:45', '2020-08-01 14:22:45');
INSERT INTO `lms_admin_operation_log` VALUES (722, 1, 'admin/products', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2020-08-01 14:23:30', '2020-08-01 14:23:30');

-- ----------------------------
-- Table structure for lms_admin_permissions
-- ----------------------------
DROP TABLE IF EXISTS `lms_admin_permissions`;
CREATE TABLE `lms_admin_permissions`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `http_method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `http_path` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `lms_admin_permissions_name_unique`(`name`) USING BTREE,
  UNIQUE INDEX `lms_admin_permissions_slug_unique`(`slug`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_admin_permissions
-- ----------------------------
INSERT INTO `lms_admin_permissions` VALUES (1, 'All permission', '*', '', '*', NULL, NULL);
INSERT INTO `lms_admin_permissions` VALUES (2, 'Dashboard', 'dashboard', 'GET', '/', NULL, NULL);
INSERT INTO `lms_admin_permissions` VALUES (3, 'Login', 'auth.login', '', '/auth/login\r\n/auth/logout', NULL, NULL);
INSERT INTO `lms_admin_permissions` VALUES (4, 'User setting', 'auth.setting', 'GET,PUT', '/auth/setting', NULL, NULL);
INSERT INTO `lms_admin_permissions` VALUES (5, 'Auth management', 'auth.management', '', '/auth/roles\r\n/auth/permissions\r\n/auth/menu\r\n/auth/logs', NULL, NULL);
INSERT INTO `lms_admin_permissions` VALUES (6, '商家', 'shops', '', '/\r\n/auth/login\r\n/auth/logout\r\n/auth/setting\r\n/products*\r\n/shops*', '2020-07-30 05:37:59', '2020-07-30 08:57:21');

-- ----------------------------
-- Table structure for lms_admin_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `lms_admin_role_menu`;
CREATE TABLE `lms_admin_role_menu`  (
  `role_id` int(0) NOT NULL,
  `menu_id` int(0) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  INDEX `lms_admin_role_menu_role_id_menu_id_index`(`role_id`, `menu_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_admin_role_menu
-- ----------------------------
INSERT INTO `lms_admin_role_menu` VALUES (1, 2, NULL, NULL);
INSERT INTO `lms_admin_role_menu` VALUES (1, 12, NULL, NULL);
INSERT INTO `lms_admin_role_menu` VALUES (2, 12, NULL, NULL);
INSERT INTO `lms_admin_role_menu` VALUES (1, 11, NULL, NULL);
INSERT INTO `lms_admin_role_menu` VALUES (2, 11, NULL, NULL);
INSERT INTO `lms_admin_role_menu` VALUES (1, 8, NULL, NULL);
INSERT INTO `lms_admin_role_menu` VALUES (1, 10, NULL, NULL);

-- ----------------------------
-- Table structure for lms_admin_role_permissions
-- ----------------------------
DROP TABLE IF EXISTS `lms_admin_role_permissions`;
CREATE TABLE `lms_admin_role_permissions`  (
  `role_id` int(0) NOT NULL,
  `permission_id` int(0) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  INDEX `lms_admin_role_permissions_role_id_permission_id_index`(`role_id`, `permission_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_admin_role_permissions
-- ----------------------------
INSERT INTO `lms_admin_role_permissions` VALUES (1, 1, NULL, NULL);
INSERT INTO `lms_admin_role_permissions` VALUES (2, 6, NULL, NULL);

-- ----------------------------
-- Table structure for lms_admin_role_users
-- ----------------------------
DROP TABLE IF EXISTS `lms_admin_role_users`;
CREATE TABLE `lms_admin_role_users`  (
  `role_id` int(0) NOT NULL,
  `user_id` int(0) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  INDEX `lms_admin_role_users_role_id_user_id_index`(`role_id`, `user_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_admin_role_users
-- ----------------------------
INSERT INTO `lms_admin_role_users` VALUES (1, 1, NULL, NULL);
INSERT INTO `lms_admin_role_users` VALUES (2, 2, NULL, NULL);

-- ----------------------------
-- Table structure for lms_admin_roles
-- ----------------------------
DROP TABLE IF EXISTS `lms_admin_roles`;
CREATE TABLE `lms_admin_roles`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `lms_admin_roles_name_unique`(`name`) USING BTREE,
  UNIQUE INDEX `lms_admin_roles_slug_unique`(`slug`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_admin_roles
-- ----------------------------
INSERT INTO `lms_admin_roles` VALUES (1, 'Administrator', 'administrator', '2020-07-27 07:24:34', '2020-07-27 07:24:34');
INSERT INTO `lms_admin_roles` VALUES (2, '商家', 'shops', '2020-07-30 05:38:23', '2020-07-30 05:38:23');

-- ----------------------------
-- Table structure for lms_admin_user_permissions
-- ----------------------------
DROP TABLE IF EXISTS `lms_admin_user_permissions`;
CREATE TABLE `lms_admin_user_permissions`  (
  `user_id` int(0) NOT NULL,
  `permission_id` int(0) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  INDEX `lms_admin_user_permissions_user_id_permission_id_index`(`user_id`, `permission_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_admin_user_permissions
-- ----------------------------
INSERT INTO `lms_admin_user_permissions` VALUES (2, 6, NULL, NULL);

-- ----------------------------
-- Table structure for lms_admin_users
-- ----------------------------
DROP TABLE IF EXISTS `lms_admin_users`;
CREATE TABLE `lms_admin_users`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(190) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `lms_admin_users_username_unique`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_admin_users
-- ----------------------------
INSERT INTO `lms_admin_users` VALUES (1, 'admin', '$2y$10$ezZiPlO6RxTLfZfzujWUxOjesPUmGEQB273uB0.QnCqHeHqAoocYm', 'Administrator', NULL, 'Oz0g9LKHPanpVZW2RRSnQNILTI8mqYUrELdMm04KugYBHrVuQLswsb5uH0VB', '2020-07-27 07:24:34', '2020-07-27 07:24:34');
INSERT INTO `lms_admin_users` VALUES (2, 'starsky', '$2y$10$aB9NlEoGYi3YihIobqaViOQ.NWAEeKaEzZ/p/l.hok47SwbdxQjfa', 'starsky', 'images/39DE08PR9[D21F7C~6MF3E1.png', 'U9LWfrwe7gcA9onoZQyfAYROQuWK8vZMtm8shNN8VWUXaYOQUExuSbHVMhb9', '2020-07-30 05:39:24', '2020-07-30 05:39:24');

-- ----------------------------
-- Table structure for lms_categories
-- ----------------------------
DROP TABLE IF EXISTS `lms_categories`;
CREATE TABLE `lms_categories`  (
  `id` bigint(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(0) UNSIGNED NULL DEFAULT NULL,
  `is_directory` tinyint(1) NOT NULL,
  `level` int(0) UNSIGNED NOT NULL,
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 82 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_categories
-- ----------------------------
INSERT INTO `lms_categories` VALUES (1, '手机配件', NULL, 1, 0, '-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (2, '手机壳', 1, 0, 1, '-1-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (3, '贴膜', 1, 0, 1, '-1-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (4, '存储卡', 1, 0, 1, '-1-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (5, '数据线', 1, 0, 1, '-1-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (6, '充电器', 1, 0, 1, '-1-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (7, '耳机', 1, 1, 1, '-1-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (8, '有线耳机', 7, 0, 2, '-1-7-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (9, '蓝牙耳机', 7, 0, 2, '-1-7-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (10, '电脑配件', NULL, 1, 0, '-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (11, '显示器', 10, 0, 1, '-10-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (12, '显卡', 10, 0, 1, '-10-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (13, '内存', 10, 0, 1, '-10-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (14, 'CPU', 10, 0, 1, '-10-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (15, '主板', 10, 0, 1, '-10-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (16, '硬盘', 10, 0, 1, '-10-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (17, '电脑整机', NULL, 1, 0, '-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (18, '笔记本', 17, 0, 1, '-17-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (19, '台式机', 17, 0, 1, '-17-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (20, '平板电脑', 17, 0, 1, '-17-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (21, '一体机', 17, 0, 1, '-17-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (22, '服务器', 17, 0, 1, '-17-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (23, '工作站', 17, 0, 1, '-17-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (24, '手机通讯', NULL, 1, 0, '-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (25, '智能机', 24, 0, 1, '-24-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (26, '老人机', 24, 0, 1, '-24-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (27, '对讲机', 24, 0, 1, '-24-', '2020-07-28 06:28:55', '2020-07-28 06:28:55');
INSERT INTO `lms_categories` VALUES (28, '手机配件', NULL, 1, 0, '-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (29, '手机壳', 28, 0, 1, '-28-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (30, '贴膜', 28, 0, 1, '-28-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (31, '存储卡', 28, 0, 1, '-28-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (32, '数据线', 28, 0, 1, '-28-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (33, '充电器', 28, 0, 1, '-28-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (34, '耳机', 28, 1, 1, '-28-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (35, '有线耳机', 34, 0, 2, '-28-34-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (36, '蓝牙耳机', 34, 0, 2, '-28-34-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (37, '电脑配件', NULL, 1, 0, '-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (38, '显示器', 37, 0, 1, '-37-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (39, '显卡', 37, 0, 1, '-37-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (40, '内存', 37, 0, 1, '-37-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (41, 'CPU', 37, 0, 1, '-37-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (42, '主板', 37, 0, 1, '-37-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (43, '硬盘', 37, 0, 1, '-37-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (44, '电脑整机', NULL, 1, 0, '-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (45, '笔记本', 44, 0, 1, '-44-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (46, '台式机', 44, 0, 1, '-44-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (47, '平板电脑', 44, 0, 1, '-44-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (48, '一体机', 44, 0, 1, '-44-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (49, '服务器', 44, 0, 1, '-44-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (50, '工作站', 44, 0, 1, '-44-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (51, '手机通讯', NULL, 1, 0, '-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (52, '智能机', 51, 0, 1, '-51-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (53, '老人机', 51, 0, 1, '-51-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (54, '对讲机', 51, 0, 1, '-51-', '2020-07-28 06:40:31', '2020-07-28 06:40:31');
INSERT INTO `lms_categories` VALUES (55, '手机配件', NULL, 1, 0, '-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (56, '手机壳', 55, 0, 1, '-55-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (57, '贴膜', 55, 0, 1, '-55-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (58, '存储卡', 55, 0, 1, '-55-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (59, '数据线', 55, 0, 1, '-55-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (60, '充电器', 55, 0, 1, '-55-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (61, '耳机', 55, 1, 1, '-55-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (62, '有线耳机', 61, 0, 2, '-55-61-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (63, '蓝牙耳机', 61, 0, 2, '-55-61-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (64, '电脑配件', NULL, 1, 0, '-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (65, '显示器', 64, 0, 1, '-64-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (66, '显卡', 64, 0, 1, '-64-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (67, '内存', 64, 0, 1, '-64-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (68, 'CPU', 64, 0, 1, '-64-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (69, '主板', 64, 0, 1, '-64-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (70, '硬盘', 64, 0, 1, '-64-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (71, '电脑整机', NULL, 1, 0, '-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (72, '笔记本', 71, 0, 1, '-71-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (73, '台式机', 71, 0, 1, '-71-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (74, '平板电脑', 71, 0, 1, '-71-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (75, '一体机', 71, 0, 1, '-71-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (76, '服务器', 71, 0, 1, '-71-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (77, '工作站', 71, 0, 1, '-71-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (78, '手机通讯', NULL, 1, 0, '-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (79, '智能机', 78, 0, 1, '-78-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (80, '老人机', 78, 0, 1, '-78-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');
INSERT INTO `lms_categories` VALUES (81, '对讲机', 78, 0, 1, '-78-', '2020-07-28 06:42:26', '2020-07-28 06:42:26');

-- ----------------------------
-- Table structure for lms_failed_jobs
-- ----------------------------
DROP TABLE IF EXISTS `lms_failed_jobs`;
CREATE TABLE `lms_failed_jobs`  (
  `id` bigint(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lms_migrations
-- ----------------------------
DROP TABLE IF EXISTS `lms_migrations`;
CREATE TABLE `lms_migrations`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(0) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_migrations
-- ----------------------------
INSERT INTO `lms_migrations` VALUES (1, '2014_10_12_100000_create_password_resets_table', 1);
INSERT INTO `lms_migrations` VALUES (2, '2016_01_04_173148_create_admin_tables', 1);
INSERT INTO `lms_migrations` VALUES (3, '2019_08_19_000000_create_failed_jobs_table', 1);

-- ----------------------------
-- Table structure for lms_password_resets
-- ----------------------------
DROP TABLE IF EXISTS `lms_password_resets`;
CREATE TABLE `lms_password_resets`  (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  INDEX `lms_password_resets_email_index`(`email`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lms_user_info
-- ----------------------------
DROP TABLE IF EXISTS `lms_user_info`;
CREATE TABLE `lms_user_info`  (
  `id` int(0) NOT NULL,
  `user_id` char(36) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `age` int(0) NULL DEFAULT NULL,
  `image` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `birthday` datetime(0) NULL DEFAULT NULL,
  `email` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sex` tinyint(1) NULL DEFAULT NULL,
  `identity_type` tinyint(1) NULL DEFAULT NULL,
  `identity_no` char(18) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `user_description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `level_id` int(0) NULL DEFAULT NULL,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  `deleted_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lms_user_roles
-- ----------------------------
DROP TABLE IF EXISTS `lms_user_roles`;
CREATE TABLE `lms_user_roles`  (
  `role_id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `group_id_array` int(0) NULL DEFAULT NULL,
  `is_role` int(0) NULL DEFAULT NULL,
  `role_status` tinyint(1) NULL DEFAULT NULL,
  `desc` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_user_roles
-- ----------------------------
INSERT INTO `lms_user_roles` VALUES (1, '普通用户', 1, 0, 1, NULL);
INSERT INTO `lms_user_roles` VALUES (2, '一级会员', 2, 0, 1, NULL);

-- ----------------------------
-- Table structure for lms_users
-- ----------------------------
DROP TABLE IF EXISTS `lms_users`;
CREATE TABLE `lms_users`  (
  `id` char(36) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户id',
  `Openid` char(28) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'openid',
  `username` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户名称',
  `password` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '密码',
  `role_id` int(0) NULL DEFAULT NULL COMMENT '用户角色id',
  `vender_type` tinyint(1) NULL DEFAULT NULL COMMENT '第三方类型:1.QQ,2:微信',
  `status` tinyint(1) NULL DEFAULT NULL COMMENT '用户状态：1. 黑名单',
  `mobile` char(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号码',
  `login_ip` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '登录ip',
  `remember_token` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'token验证',
  `created_at` datetime(0) NULL DEFAULT NULL COMMENT '注册时间',
  `updated_at` datetime(0) NULL DEFAULT NULL COMMENT '最后一次修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lms_users
-- ----------------------------
INSERT INTO `lms_users` VALUES ('9d8e129b-bb21-d997-ad14-4af5c93aac3d', 'oqCL0s8DkK6CZy_cZFEx0TvfUM_Y', '星空', NULL, 1, 1, 1, NULL, '127.0.0.1', 'cmMNR4zCHradzojq21c05DCS1WE8p2fOKUkzGnkiJ59kx2xjkkNSyfcyGdHw', '2020-07-28 08:23:47', '2020-07-28 08:23:47');

SET FOREIGN_KEY_CHECKS = 1;
