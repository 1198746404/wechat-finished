<?php

namespace App\Http\Controllers\Admin;

use App\Events\RegisterEvent;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    public function register(Request $request)
    {
//        $data = $request->except('_token');
//        $id = User::create($data)->id;
//
//        if ($id) {
//            event(new RegisterEvent('你喜欢那种恭喜？'));
//        }
//        return redirect('login');

        # 观察者
        $data = $request->except('_token');
        User::create($data);
        return redirect('login');
    }
}
