<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('role')->only('index');
    }

    public function index()
    {
//        dd(session()->all());
        $users = User::paginate(5);
        $assign = compact('users');
        return view('index.list', $assign);
    }


    # 编辑
    public function edit($id)
    {
        $user = User::find($id);
        return view('index.edit', ['user' => $user]);
    }

    # 修改数据
    public function update(Request $request)
    {
        # 方法1
        $data = $request->except('_token');
        $user = User::find($request->id);
        $user->update($data);

        return redirect('index');
    }


    # 添加数据
    public function create()
    {
        return view('index.add');
    }

    public function store(Request $request)
    {
        $data = $request->except('_token');
        $data['password'] = Hash::make($data['password']);

        $res = User::create($data);
        return redirect('index');
    }


    # 详情页
    public function show($id)
    {
        $user = User::find($id);
        $userInfo = $user->userInfo;

        $user = [
            'id' => $id,
            'name' => $user->name,
            'age' => $userInfo->age,
            'sex' => $userInfo->sex,
            'created_at' => $userInfo->created_at,
            'updated_at' => $userInfo->updated_at,
        ];

        return view('index.show', ['user' => $user]);
    }

    # destory

}
