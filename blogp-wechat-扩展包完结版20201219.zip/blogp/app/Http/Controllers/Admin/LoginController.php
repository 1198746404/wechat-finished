<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    # 登录  待完善
    public function login(Request $request)
    {
        session()->put('role', $request->get('role'));
//        dd(session()->all());
        return view('index.index');
    }

    public function logout(Request $request)
    {
        session()->forget('role');
        return redirect('login');
    }


}
