<?php

namespace App\Models;


class UserInfo extends BaseModel
{
    
}
