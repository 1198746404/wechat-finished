<?php

namespace App\Console\Commands;

use Illuminate\Console\GeneratorCommand;

# 需要继承 GeneratorCommand 类，并且重写 getStub 方法
class ObjectCommand extends GeneratorCommand
{
    # 命令名称
    protected $name = 'make:object';

    # 命令描述
    protected $description = 'crate a new object';

    protected $type = 'object';


    # 获取生成器文件目录
    protected function getStub()
    {
        # 模拟框架的方式 Illuminate\Foundation\Console 中的实现
        return __DIR__.'/stubs/object.stub';
    }

    # 获取该类的默认名称空间  $rootNamespace 代表的是 app 目录
    protected function getDefaultNamespace($rootNamespace)
    {
        return $rootNamespace . '/Object';
    }
}
