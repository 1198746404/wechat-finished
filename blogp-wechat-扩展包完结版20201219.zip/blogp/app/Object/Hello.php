<?php

namespace App\Object;


class Hello
{
    public function index()
    {
        // 全新的对象
    }
}