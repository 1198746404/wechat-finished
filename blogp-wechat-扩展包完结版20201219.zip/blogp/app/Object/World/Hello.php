<?php

namespace App\Object\World;


class Hello
{
    public function index()
    {
        // 全新的对象
    }
}