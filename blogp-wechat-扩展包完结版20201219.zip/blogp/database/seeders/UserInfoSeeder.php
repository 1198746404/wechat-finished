<?php

namespace Database\Seeders;

use App\Models\UserInfo;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UserInfoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for ($i = 0; $i < 15; $i++) {
            $info = [
                'age' => rand(0, 100),
                'sex' => rand(0,1) ? '女': '男',
                'user_id' => rand(1,15)
            ];
            DB::table('user_infos')->insert($info);
        }
    }
}
