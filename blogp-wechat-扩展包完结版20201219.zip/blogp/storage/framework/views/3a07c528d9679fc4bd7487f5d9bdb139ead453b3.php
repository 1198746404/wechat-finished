<?php echo $__env->make('public.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="span11">
    <div class="page-header">
        <h3></h3>
    </div>

    <div class="row-fluid">
        <div class="span12">
            <div class="add">
                <a href="<?php echo e(url('create')); ?>">增加管理员</a>
            </div>
            <table width="100%" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th width="32">序号</th>
                    <th width="42">姓名</th>
                    <th width="47">邮箱</th>
                    <th width="90" class="hidden-phone">创建时间</th>
                    <th width="33">操作</th>
                </tr>
                </thead>

                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->created_at); ?></td>
                        <td>
                            <a class="btn btn-small" href="<?php echo e(route('edit', ['id' => $user->id])); ?>"><i class="icon-edit"></i> 编辑</a>
                            <a class="btn btn-smaell" href=""><i class="icon-trash"></i> 删除</a>
                            <a class="btn btn-smaell" href="<?php echo e(route('show', ['id' => $user->id])); ?>"><i class="icon-user"></i> 详情</a>
                        </td>
                    </tr>
                    </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>

            <?php echo e($users->links()); ?>


        </div>
    </div>
</div>

<?php echo $__env->make('public.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\tools\php\phpstudy_pro201129\WWW\framework\laravel\laravel2012\project\blogp\resources\views/index/list.blade.php ENDPATH**/ ?>