<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>wechat</title>
</head>
<body>
    欢迎来到手写 wechat 自动回复
</body>
</html><?php /**PATH D:\tools\php\phpstudy_pro201129\WWW\framework\laravel\laravel2012\project\wechat\src\providers/../Resources/views/welcome.blade.php ENDPATH**/ ?>