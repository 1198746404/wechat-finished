<?php echo $__env->make('public.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="span10">

    <div class="page-header">
        <h3>更新个人信息</h3>
    </div>

    <div class="row-fluid">
        <div class="span12">

            <form class="form-horizontal" method="post" action="<?php echo e(url('update')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                <div class="control-group">
                    <label for="input01" class="control-label">姓&nbsp;&nbsp;&nbsp;&nbsp;名：</label>
                    <div class="controls">
                        <input type="text" id="name" class="input-xlarge" name="name" value="<?php echo e($user->name); ?>">
                    </div>
                </div>
                <div class="control-group">
                    <label for="input01" class="control-label">邮&nbsp;&nbsp;&nbsp;&nbsp;箱：</label>
                    <div class="controls">
                        <input type="text" id="name" class="input-xlarge" name="email" value="<?php echo e($user->email); ?>">
                    </div>
                </div>

                <div class="form-actions">
                    <button class="btn btn-success" type="submit">保存</button>
                    <a class="btn" href=""><i class="icon-share"></i> 返回</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php echo $__env->make('public.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\tools\php\phpstudy_pro201129\WWW\framework\laravel\laravel2012\project\blogp\resources\views/index/edit.blade.php ENDPATH**/ ?>