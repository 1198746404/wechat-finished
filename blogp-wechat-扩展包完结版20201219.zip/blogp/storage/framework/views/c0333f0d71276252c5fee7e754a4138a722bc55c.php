<?php echo $__env->make('public.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="span11">
    <div class="page-header">
        <h3></h3>
    </div>

    <div class="row-fluid">
        <div class="span12">
            <div class="add">
                <?php echo e($user['name']); ?>详情
            </div>
            <table width="100%" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th width="32">序号</th>
                    <th width="42">姓名</th>
                    <th width="47">年龄</th>
                    <th width="90" class="hidden-phone">性别</th>
                    <th width="33">创建时间</th>
                    <th width="33">修改时间</th>
                </tr>
                </thead>

                    <tbody>
                    <tr>
                        <td><?php echo e($user['id']); ?></td>
                        <td><?php echo e($user['name']); ?></td>
                        <td><?php echo e($user['age']); ?></td>
                        <td><?php echo e($user['sex']); ?></td>
                        <td><?php echo e($user['created_at']); ?></td>
                        <td><?php echo e($user['updated_at']); ?></td>
                    </tr>
                    </tbody>

            </table>


        </div>
    </div>
</div>

<?php echo $__env->make('public.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\tools\php\phpstudy_pro201129\WWW\framework\laravel\laravel2012\project\blogp\resources\views/index/show.blade.php ENDPATH**/ ?>